<?php
require_once './vendor/autoload.php';
use Lib\DelayQueue;
$delay = new DelayQueue();
$ttl            =  100000;//订单100s后超时
$delayExName    = 'order_exchange';//超时exchange
$delayQueueName = 'order-queue';//超时queue
$queueName      = 'ttl-queue';//订单queue

$delay->createQueue($ttl, $delayExName, $delayQueueName, $queueName);
// //100个订单信息，每个订单超时时间都是10s
for ($i = 0; $i < 100; $i++) {
    $data = [
        'order_id' => $i + 1,
        'remark'   => 'this is a order test'
    ];
    $delay->sendMessage(json_encode($data), $queueName);
    // sleep(10);
}
