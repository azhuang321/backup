<?php
class Util{
    /**
     *  获取毫秒时间
     *
     */
    public static function getTime(){
        return ceil(microtime(true) * 1000);
    }
    /**
     * 记录具体方法运行耗时
     *
     * @param [type] $class_name 类名
     * @param [type] $function_name 方法名
     * @param [type] $start_time 方法开始时间
     * @param [type] $std_time 标准耗时(单位：毫秒)
     * @param string $arg
     * @return void
     */
    public static function runtime($class_name, $function_name, $start_time, $std_time, $arg = "")
    {
        if($std_time > 110) $std_time = 110;
        $need_time = Util::getTime() - $start_time;
        if($need_time > $std_time) {
            if($need_time > 150)
            {
                Util::log($class_name, "::", $function_name, $need_time, $arg, 'call_link_open');
            }
            else
            {
                Util::log($class_name, "::", $function_name, $need_time, $arg);
            }
        }
    }
    public static function log(...$args)
    {
        $str = "";
        $call_link_open = false;
        foreach ($args as $obj)
        {
            if($obj === 'call_link_open')
            {
                $call_link_open = true;
                continue;
            }
            $str = $str . ' '  . $obj;
        }
        $str = $str . "\n";
        echo  $str;

        if($call_link_open)
        {
            $array =debug_backtrace();
            unset($array[0]);
            $log_link = '/--------------调用链---------------/'.PHP_EOL;
            $unp_type = ['object', 'array'];
            foreach($array as $row)
            {
                $continue_act = 0;
                if(isset($row['file']) && strstr($row['file'], '/vendor/workerman/gateway-worker/src/BusinessWorker.php'))
                {
                    $continue_act = 1;
                }
                if($continue_act) continue;

                if(isset($row['file']) && isset($row['line']) && isset($row['function'])){
                    $args_str = PHP_EOL;
                    if(isset($row['args']))
                    {
                        foreach ($row['args'] as $kk => $vv) {
                            $vv_type = getType($vv);
                            $vv_str = in_array($vv_type, $unp_type) ? $vv_type : (string)$vv;
                            $vv_str = $vv_str ? $vv_str : 'null';
                            $args_str .= $vv_str . ', ';
                        }
                    }
                    $args_str .= PHP_EOL;
                    $log_link .=$row['file'].':'.$row['line'].'行,调用方法:'.$row['function'].'传入参数:'.$args_str.PHP_EOL;
                }
            }
            $log_link .= '/--------------调用链end------------/'.PHP_EOL;
            echo $log_link . PHP_EOL;
        }
    }
    /**
     * 获取rolekey
     */
    public static function getRoleKey($game_role_id, $type = ""){
        return  $roleKey = 'role_' .$game_role_id. "_" . $type;
    }
    /** 是否人物 */
    public static function checkPlayerByRoleIdNotRobot($game_role_id) {
        return $isPlayer = ($game_role_id > 0 && $game_role_id < Commads::$IDBegin_cache_player) || $game_role_id > Commads::$IDBegin_cache_crossplayer;
    }
}