<?php


class Rediss{

    public static $_redis;

    public function __construct(){
        if(empty(Rediss::$_redis)) {
            $config = Events::$public_config;
//            Rediss::$_redis = new Redis();
//            Rediss::$_redis->connect($config['redis_ip'],$config['redis_port']);
//            if($config['redis_auth'] != "")Rediss::$_redis->auth($config['redis_auth']);
//            Rediss::$_redis->select($config['redis_index']);
            $configs = array(
                'host'=> $config['redis_ip'],
                'port'=> $config['redis_port'],
                'auth'=> $config['redis_auth'] != "" ? $config['redis_auth'] :'',
            );
            return Rediss::$_redis = \Lib\Redis::getInstance($configs, array('db_id'=>$config['redis_index'],'timeout' => 60 ));
        }
        return Rediss::$_redis;
    }

    public function string_get(string $string){
        return Rediss::$_redis->get($string);
    }

    public function string_set($string, $value){
        Rediss::$_redis->set($string, $value);
    }
}