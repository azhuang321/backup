<?php



class Log extends BaseServices
{
    //新log系統:人物變量log
    public static function newGameLogValue(...$args){
        $roleid = $args[0];
        $args[0] = Events::getPlayerValue($roleid, 'guid');
        $msg = '';
        foreach ($args as $value) {
            $msg = $msg.$value.'v|v';
        }
        $msg = $msg.time();
        Rediss::$_redis->rPush(Events::$tally->m_server_id.'_system_value_log_game', $msg);
    }
}