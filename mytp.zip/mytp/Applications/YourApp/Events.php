<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */

/**
 * 用于检测业务代码死循环或者长时间阻塞等问题
 * 如果发现业务卡死，可以将下面declare打开（去掉//注释），并执行php start.php reload
 * 然后观察一段时间workerman.log看是否有process_timeout异常
 */
//declare(ticks=1);

use GatewayWorker\Lib\Gateway;
use \Workerman\Lib\Timer;
require_once __DIR__ . '/../Channel/Client.php';
require_once __DIR__ . '/../GlobalData/Client.php';
require_once __DIR__ . '/../Statistics/Clients/StatisticClient.php';
/**
 * 主逻辑
 * 主要是处理 onConnect onMessage onClose 三个方法
 * onConnect 和 onClose 如果不需要可以不用实现并删除
 */
class Events
{
    public static $public_config;
    public static $Channel_Client = null;

    public static $Public_data = array(); //共享数据

    public static $global = null; //共享数据

    public static $message_jsonopen; //1为json 0为二进制

    public static function setConfig($config){
        Events::$public_config = $config;
    }

    public static $mysql_operation;
    public static $redis_operation;

    public static $game;

    //用户列表
    public static $user_list = array();

    /** 上报数据 */
    public static $tally;

    /**
     * 启动worker
     */
    public static function onWorkerStart(){
        Events::$mysql_operation = new Mysqls();
        Events::$redis_operation = new Rediss();
        Events::init();
    }
    public static function init(){
        try{
            $start_time = Util::getTime();
            self::$message_jsonopen = Events::$public_config['json_mode'];
            self::$game = new Game();
            self::$tally = new Tally();
            Timer::add(1,function (){
                if(empty(self::$user_list)){
//                    Db::name("im_user")->where("1=1")->update(['status'=>"offline"]);
                    $im_user_info = Rediss::$_redis->hGetAll("im_user_info");
                    foreach ($im_user_info as $key => $value){
                        if(is_numeric($value)){
                            Rediss::$_redis->hSet('im_user_status_'.$value,"status","offline");
                        }
                    }
                }
            });
        }catch(customException $exception){
            echo $exception->errorMessage();
        }

        //Channel分布式通讯组件------------------------------------------
        /*
        // Channel客户端连接到Channel服务端
        Channel\Client::connect();
        // 使用 Unix Domain Socket 通讯
        //Channel\Client::connect('unix:///tmp/workerman-channel.sock');
        Channel\Client::on('onCrossServerData', function($event_data) {
            Events::onCrossServerData(null, $event_data);
        });

        // 要订阅的事件名称（名称可以为任意的数字和字符串组合）
        $event_name = 'event_xxxx';
        // 订阅某个自定义事件并注册回调，收到事件后会自动触发此回调
        Channel\Client::on($event_name, function($event_data){
            echo 'test event triggered event_data :';
            var_dump($event_data);
        });
        Timer::add(2, function(){
            Channel\Client::publish('onCrossServerData', 'some data');
        });
        */
        //Channel分布式通讯组件------------------------------------------end;


        //Channel分布式通讯组件enqueue队列-----------------------------------------------------
        /*
        Channel\Client::connect();
        //存入10个队列
        $i = 0;
        $timerId = Timer::add(1, function() use (&$i, &$timerId) {
            $i++;
            Channel\Client::enqueue('task-queue', 'hello every '.$i.' seconds');
            var_dump($i);
            if ($i == 10) {
                Timer::del($timerId);
            }
        });
        */
        //Channel分布式通讯组件enqueue队列-----------------------------------------------------end


        //Channel分布式通讯组件分组分发-----------------------------------------------------------
        /*
        try{
            Channel\Client::connect();
            // 监听全局分组发送消息事件
            Channel\Client::on('send_to_group', function($event_data){
                $group_id = $event_data['group_id'];
                $message = $event_data['message'];
                var_dump(array_keys(Events::$group_map));   //array_keys函数返回包含数组中所有键名
                if (isset(Events::$group_map[$group_id])) {
                    foreach (Events::$group_map[$group_id] as $client_id) {
                        Gateway::sendToClient($client_id,$message);
                    }
                }
            });
        }catch (customException $exception){
            echo $exception->errorMessage() . "\n";
        }
        */
        //Channel分布式通讯组件分组分发-----------------------------------------------------------end


        //GlobalData变量共享组件-----------------------------------------------------------
        /*
        //第一种
//        Events::$global = new GlobalData\Client('127.0.0.1:2207');
//        Events::$global->a = array(1,3);
        //第二种用法
        global $global_s;
        $global_s = new GlobalData\Client('127.0.0.1:2207');
        $global_s->a = array(1,3);
        //add();原子添加
        if($global_s->add('some_key', 10)) {
            // $global->some_key赋值成功
            echo "add success " , $global_s->some_key;
        } else {
            // $global->some_key已经存在，赋值失败
            echo "add fail " , var_export($global_s->some_key);
        }
        //cas():原子替换
        // 初始化列表
        $global_s->user_list = array(1,2,3);
        // 向user_list原子添加一个值
        do {
            $old_value = $new_value = $global_s->user_list;
            $new_value[] = 4;
        }
        while(!$global_s->cas('user_list', $old_value, $new_value));
        var_export($global_s->user_list);
        */
        //GlobalData变量共享组件-----------------------------------------------------------end

        //mysql组件
//        $data = Events::$mysql_operation->admin_info();
//        var_dump($data);

        //redis组件
//        Events::$redis_operation->string_set("nihao",1);
//        $retval = Events::$redis_operation->string_get("nihao");
//        var_dump($retval);
//        var_dump(Rediss::$_redis->get("nihao"));


        //
        // 统计开始
//        StatisticClient::tick("User", 'getInfo');
        // 统计的产生，接口调用是否成功、错误码、错误日志
//        $success = false; $code = 0; $msg = '错误';
        // 假如有个User::getInfo方法要监控
        // $user_info = User::getInfo();
        // if(!$user_info){
        //     // 标记失败
        //     $success = false;
        //     // 获取错误码，假如getErrCode()获得
        //     $code = User::getErrCode();
        //     // 获取错误日志，假如getErrMsg()获得
        //     $msg = User::getErrMsg();
        // }
        // 上报结果
//        StatisticClient::report('User', 'getInfo', $success, $code, $msg);

        Util::runtime(__CLASS__, __FUNCTION__, $start_time, 150);
    }

//    public static function onCrossServerData($connection, $vo){
//        echo 'onCrossServerData';
//        var_dump($vo);
//    }

    //测试共享全局变量
    public static function global_data($client_id=''){
        global $global_var;
        if(!empty($client_id)){
            $global_var[$client_id] = $client_id;
        }
        return $global_var;
    }
    //测试共享静态变量
    public static function public_data($client_id=''){
        if(!empty($client_id)){
            self::$Public_data[$client_id] = $client_id;
        }
        return self::$Public_data;
    }
    /**
     * 当客户端连接时触发
     * 如果业务不需此回调可以删除onConnect
     * 
     * @param int $client_id 连接id
     */
    public static function onConnect($client_id)
    {
        // 向当前client_id发送数据 
//        Gateway::sendToClient($client_id, "Hello $client_id\r\n");
        // 向所有人发送
//        Gateway::sendToAll("$client_id login\r\n");

        //共享变量数据-----------------------
//        self::public_data($client_id);
//        self::global_data($client_id);
        //共享变量数据-----------------------end

        //GlobalData变量共享组件-----------------------------------------------------------
//        var_dump(Events::$global->a);
//        var_dump(isset(Events::$global->w));
//        global $global_s;
//        var_dump($global_s->a);
//        var_dump($global_s->some_key);
        //GlobalData变量共享组件-----------------------------------------------------------end
    }

    public static $group_con_map = array();
    public static $group_map = array();

   /**
    * 当客户端发来消息时触发
    * @param int $client_id 连接id
    * @param mixed $message 具体消息
    */
   public static function onMessage($client_id, $message) {
       var_dump($message);
       if(self::$message_jsonopen) {
           if(array_key_exists($client_id, self::$msg) == false) {
               self::$msg[$client_id] = $message;
           }else{
               self::$msg[$client_id] = self::$msg[$client_id] . $message;
           }
           self::parseData($client_id);
       }
       Events::$m_handle_data[$client_id] = 0;
//       if(strlen(self::$msg[$client_id])> 0) self::parseData($client_id);
       if(strlen(self::$msg[$client_id])> 0){
           self::$msg[$client_id] = "";
       };

//       self::parseData($client_id);

       // 向所有人发送
//       Gateway::sendToAll("$client_id said $message\r\n");


       //共享变量数据-----------------------
//       var_dump(self::$Public_data);
//       var_dump(self::global_data());
       //全局对象、类的静态成员不会释放
       //共享变量数据-----------------------end

       //Channel分布式通讯组件-----------------------
       /*
       // 要发布的事件名称
       $event_name = 'event_xxxx';
       // 事件数据（数据格式可以为数字、字符串、数组），会传递给客户端回调函数作为参数
       $event_data = array('some data.', 'some data..');
       // 发布某个自定义事件，订阅这个事件的客户端会收到事件数据，并触发客户端对应的事件回调
       Channel\Client::publish($event_name, $event_data);
       $event_data = array('onCrossServerData data.', 'onCrossServerData data..');
       Channel\Client::publish('onCrossServerData', $event_data);
       */
       //Channel分布式通讯组件-----------------------end


        //Channel分布式通讯组件enqueue队列-----------------------------------------------------
       /*
       //每次取2个队列
       $countDown = 2;
       $id = 1;
       Channel\Client::watch('task-queue', function($data) use ( &$countDown, &$id) {
           echo "[$id] Worker get queue: $data\n";
           sleep(0.2);
           $countDown--;
           $id++;
           if ($countDown == 0) {
               Channel\Client::unwatch('task-queue');
           }
           Timer::add(1, [Channel\Client::class, 'reserve'], [], false);
       });
       */
        //Channel分布式通讯组件enqueue队列-----------------------------------------------------end


       //Channel分布式通讯组件分组分发-----------------------------------------------------------
       /*
       // 加入群组消息{"cmd":"add_group", "group_id":"123"}
       // 或者 群发消息{"cmd":"send_to_group", "group_id":"123", "message":"这个是消息"}
       $data = json_decode($message, true);
//       var_dump($data);
       $cmd = $data['cmd'];
       $group_id = $data['group_id'];

       switch($cmd){
           // 连接加入群组
           case "add_group":
               // 将连接加入到对应的群组数组里
               Events::$group_map[$group_id][$client_id] = $client_id;
               // 记录这个连接加入了哪些群组，方便在onclose的时候清理group_con_map对应群组的数据
               Events::$group_con_map[$client_id][$group_id] = isset($client_id->group_id) ? $client_id->group_id : array();
               Events::$group_con_map[$client_id][$group_id][$group_id] = $group_id;

//               $client_id->group_id = isset($client_id->group_id) ? $client_id->group_id : array();
//               $client_id->group_id[$group_id] = $group_id;
               break;
           // 群发消息给群组
           case "send_to_group":
               // Channel\Client给所有服务器的所有进程广播分组发送消息事件
               Channel\Client::publish('send_to_group', array(
                   'group_id'=>$group_id,
                   'message'=>$data['message']
               ));
               break;
       }
       */
       //Channel分布式通讯组件分组分发-----------------------------------------------------------end
   }
    public static $msg = array();
    public static $m_handle_data = array();
    public static $unChkCmds = array("001","002");  //不侦测的命令
    public static $mGameRoleIds = array ();
    public static $mSelectRoleid = array ();
    public static $playerList = array ();
    /**
     * 当客户端发来消息时触发
     * @param int $client_id 连接id
     * @param mixed $message 具体消息
     */
    public static function parseData($client_id){
        try {
            $keyindex = strpos(self::$msg[$client_id], "^^^");
            $msglen = substr(self::$msg[$client_id], 0, $keyindex);
            if(!is_numeric($msglen)){
                Util::log("error-1"); return;
            }
            $trueLen = $msglen + strlen($msglen) + 3;
            if(strlen(self::$msg[$client_id]) != $trueLen){
                Util::log("error-2"); return;
            }
            if(array_key_exists($client_id, Events::$m_handle_data) == false) {
                Events::$m_handle_data[$client_id] = 0;
            }
            if(Events::$m_handle_data[$client_id] == 1){
                Util::log("error-3"); return;
            }
            Events::$m_handle_data[$client_id] = 1;
            $message = substr(self::$msg[$client_id], strlen($msglen) + 3, $trueLen);
            self::$msg[$client_id] = substr(self::$msg[$client_id], $trueLen, strlen(self::$msg[$client_id]));
            if(empty(Events::$redis_operation) || empty(Rediss::$_redis)) {
                Util::log("error-redis");
                return;
            }
            if(empty($message) || $message == "") {
                Util::log("error-message");
                return;
            }

            $vo = json_decode($message);
            if(empty($vo)) {
                Util::log("error-json-message", $message);
                return;
            }
            $vo->client = $client_id;
            //该命令需侦测
            if (!in_array($vo->cmdid, self::$unChkCmds)) {
                $second = 1000;   //多少内秒(毫秒)
                $cishu = 2;    //次数
                self::checkCmdTime($client_id, $vo->cmdid, $second, $cishu);
//                self::insertCmd($vo->cmdid);
//                self::checkRepeatCmd($client_id);
            }
            switch($vo->cmdid){
                case "1300":    //ping
                    break;
                case Commads::$C1411:
                    self::GET1411($client_id,$vo->data);
                    break;
                default:
                    if(empty(self::$mGameRoleIds[$client_id]) == false) {
                        $game_role_id = self::$mGameRoleIds[$client_id];
                        $start_time = Util::getTime();
                        GOperation::notifyEvent("s_" . $vo->cmdid, $game_role_id, $vo->cmdid, $vo->data);
                        $runtime_line = Events::getGValue('runtime_line');
                        if ($runtime_line > 0) {
                            $delta_time = Util::getTime() - $start_time;
                            if ($delta_time > $runtime_line) {
                                Util::log($vo->cmdid.' 耗时 '.$delta_time);
                            }
                        }
                    }else{
                        Util::log('错误client' . $client_id);
                    }

                    break;
            }

        }catch (customException $e){
            echo $e->errorMessage() . "\n";
            $success = true; $code = 0; $msg = '';
            StatisticClient::report('User', 'getInfo', $success, $code, $e->errorMessage());
        }
    }
    public static function GET1411($client_id, $msg){
        if(!isset($msg->sessionid) && !isset($msg->sessionname)){
            $re = [
                'code' => 403,
                'msg'   => '登录授权失败'
            ];
            Gateway::sendToClient($client_id, Events::packMsg(Commads::$C1100, $re));
            return;
        }
        if(Gateway::isUidOnline($msg->sessionid)){
            $re = [
                'code' => 403,
                'msg'   => '已在其他地方登陆'
            ];
            Gateway::sendToClient(self::$mSelectRoleid[$msg->sessionid], Events::packMsg(Commads::$C1100, $re));
        }
        self::$mGameRoleIds[$client_id] = $msg->sessionid;          //$mGameRoleIds:游戏内的客户端client_id 用户
        self::$mSelectRoleid[$msg->sessionid] = $client_id;

        $game_role_id = $msg->sessionid;
        Events::$playerList[$game_role_id]['client'] = $client_id;      //$playerList:所有用户的信息
        Events::$playerList[$game_role_id]['online'] = true;
        Events::$user_list[$game_role_id] = Rediss::$_redis->hGetAll("im_user_".$msg->sessionid);
        Gateway::bindUid($client_id, $msg->sessionid);

        //更改在线
        Rediss::$_redis->hSet("im_user_".$msg->sessionid,"status","online"); //标记为在线
        Rediss::$_redis->hSet("im_user_status_".$msg->sessionid,"status","online"); //标记为在线

        //获取未读消息盒子数量
        $im_system_message_count = Rediss::$_redis->get("im_system_message_count:".$msg->sessionid);
        $re = [
            "count"     => $im_system_message_count
        ];
        Gateway::sendToClient($client_id, Events::packMsg(Commads::$C1500, $re));

        //给好友发送上线通知，用来标记头像去除置灰
        $friend_lLen = Rediss::$_redis->lLen('im_user_friend_u'.$msg->sessionid);
        $friend_list = Rediss::$_redis->lRange('im_user_friend_u'.$msg->sessionid,0,$friend_lLen);
        $data = [
            "uid"   => $msg->sessionid,
            "status"=> 'online'
        ];
        if(!empty($friend_list)){
            foreach ($friend_list as $v){
                if(Gateway::isUidOnline($v)){ //判断用户是否在线，用户在线推送好友上线消息
                    self::sendToFriend($v,Commads::$C1702,$data);
                }
            }
        }
        unset($friend_list);
        unset($data);
        //更新聊天离线未读消息
        $offline_messgae_lLen = Rediss::$_redis->lLen('im_offline_message_'.$msg->sessionid);
        $offline_messgae = Rediss::$_redis->lRange('im_offline_message_'.$msg->sessionid,0,$offline_messgae_lLen);
        if(!empty($offline_messgae)){
            foreach ($offline_messgae as $k=>$v) {
                $v = json_decode($v,true);
                $vs = json_decode($v['data'],true);
                self::sendToFriend($msg->sessionid,Commads::$C1703,$vs);
                //如果推送成功标记当前离线消息为已发送
                Rediss::$_redis->lPop('im_offline_message_'.$msg->sessionid);
            }
        }
        unset($offline_messgae);
    }
    private static $mGValues = array();
    /**
     * 获取全局变量
     */
    public static function getGValue($key){
        if(array_key_exists($key, self::$mGValues) == false) {
            Events::$mGValues[$key] = Rediss::$_redis->hGet("a_gvalue", $key);
            if(empty(Events::$mGValues[$key]) || Events::$mGValues[$key] == false) {
                Events::$mGValues[$key] = 0;
            }
        }
        $value = Events::$mGValues[$key];
        return $value;
    }
    /**
     * 设置全局变量
     */
    public static function setGValue($key, $value){
        Events::$mGValues[$key] = $value;
        Rediss::$_redis->hSet("a_gvalue", $key, $value);
    }

    private static $mPlayerValues = array();
    /**
     * 获取变量
     */
    public static function getValue($game_role_id, $key) {
        if($game_role_id <= 0) {
            return 0;
        }
        $start_time = Util::getTime();
        $game_role_id_local = $game_role_id;
        if(array_key_exists($game_role_id, self::$mPlayerValues) == false) {
            Events::$mPlayerValues[$game_role_id] = Rediss::$_redis->hGetAll(Util::getRoleKey($game_role_id_local, Commads::$data_value));
        }

        $value = 0;
        if(array_key_exists($key, self::$mPlayerValues[$game_role_id]))
        {
            $value = Events::$mPlayerValues[$game_role_id][$key];
        }
        Util::runtime(__CLASS__, __FUNCTION__, $start_time, 150);
        return $value;
    }


    /**
     * 设置变量
     */
    public static function setValue($game_role_id, $key, $value, $send = false, $log = 0, $setlog = true) {
        if($game_role_id == 0) {
            return;
        }
//        if(Util::checkPlayerByRoleIdNotRobot($game_role_id) == false) return;
        $start_time = Util::getTime();
        $game_role_id_local = $game_role_id;
        if(array_key_exists($game_role_id, self::$mPlayerValues) == false) {
            Events::$mPlayerValues[$game_role_id] = Rediss::$_redis->hGetAll(Util::getRoleKey($game_role_id_local, Commads::$data_value));
        }
        $fvalue = Events::getValue($game_role_id, $key);
        if($fvalue === $value) return;
        // Util::log('setValue', $key, $value );
        Events::$mPlayerValues[$game_role_id][$key] = $value;
        Rediss::$_redis->hSet(Util::getRoleKey($game_role_id_local, Commads::$data_value), $key, $value);
        if($setlog){//是否记录mysql日志，默认是
            if($key == 'online_time')
            {
                if($value%100 === 0)
                {
                    Log::newGameLogValue($game_role_id, $key, $value, $fvalue, $log);
                }
            }
            else
            {
                Log::newGameLogValue($game_role_id, $key, $value, $fvalue, $log);
            }
        }
        Util::runtime(__CLASS__, __FUNCTION__, $start_time, 150);
    }

    /**
     * 获取玩家变量
     */
    public static function getPlayerValue($game_role_id, $key)
    {
        $start_time = Util::getTime();
        $game_role_id_local = $game_role_id;
        $value = 0;
        if(isset(self::$playerList[$game_role_id]) == false)
        {
            $value = Rediss::$_redis->hGet(Util::getRoleKey($game_role_id_local, Commads::$data_role), $key);
            if($value == false)
            {
                $value = 0;
            }
            return $value;
        }

        if(empty(self::$playerList[$game_role_id]))
        {
            if($key == 'online') return false;
        }
        if(array_key_exists($key, self::$playerList[$game_role_id]) == false)
        {
            $value = Rediss::$_redis->hGet(Util::getRoleKey($game_role_id, Commads::$data_role), $key);
            if($value == false)
            {
                $value = 0;
            }
            Events::$playerList[$game_role_id][$key] = $value;
        }

        if(array_key_exists($key, self::$playerList[$game_role_id]))
        {
            $value = Events::$playerList[$game_role_id][$key];
        }
        Util::runtime(__CLASS__, __FUNCTION__, $start_time, 150);
        return $value;
    }


    public static $cmds = array();  //队列，存放最近的命令

    /**
     * 将本次触发命令插入最近命令队列中
     *
     * @param [type] $cmd 本次触发命令代码
     * @return void
     */
    public static function insertCmd($cmd, $second=5) {
        $cmdsLimitSize = 20;    //$cmds队列允许最大长度
        array_push(self::$cmds, $cmd);
        if ($cmdsLimitSize < count(self::$cmds)) {
            array_shift(self::$cmds);
        }
    }
    public static $cmd_second_time = array();
    public static $cmd_second = array();
    public static function checkCmdTime($client_id,$cmd,$second=20000, $cishu=2){
        $start_time = Util::getTime();
        if(isset(self::$cmd_second[$client_id][$cmd])){
            $end_time = self::$cmd_second_time[$client_id][$cmd]['start_time'] + $second;
            if($end_time > $start_time){    //在时间内
                if(self::$cmd_second_time[$client_id][$cmd]['cishu']+1 >= $cishu){       //多少次
                    echo $client_id." 涉嫌作弊，重复指令 => ".$cmd."\n";
                    Util::runtime(__CLASS__, __FUNCTION__, $start_time, 150);
                    return ;
                }else{
                    self::$cmd_second_time[$client_id][$cmd]['cishu'] = self::$cmd_second_time[$client_id][$cmd]['cishu'] + 1;
                }
            }else{  //不在时间内
                unset(self::$cmd_second[$client_id]);
                unset(self::$cmd_second_time[$client_id]);
            }
        }else{
            //第一次
            self::$cmd_second[$client_id][$cmd] = $cmd;
            self::$cmd_second_time[$client_id][$cmd]['cishu'] = 1;
            self::$cmd_second_time[$client_id][$cmd]['start_time'] = $start_time; //193
        }
    }
    /**
     * 侦测重复指令
     *
     * @return void
     */
    public static function checkRepeatCmd($client_id) {
        $start_time = Util::getTime();
        $checked = array();     //存放已检查命令
        $limit = 5;     //多少次后再次出现相同命令算作一次重复
        foreach (self::$cmds as $key => $value) {
            if (!isset($checked[$value])) {
                //未出现过
                $checked[$value] = $value."|1|".$key;   //“checked[命令] = 命令 | 出现的总次数 | 上一次在$cmds中出现的位置”
                continue ;
            }
            //出现过时
            $str = $checked[$value];
            $lastPos = explode("|", $str)[2];   //上一次出现的位置
            if ($key - $lastPos < $limit) {
                //$limit次内再次出现
                $count = explode("|", $str)[1] + 1;
                $checked[$value] = $value."|".$count."|".$key;
                if ($count >= $limit) {
                    // print_r($checked);
                    echo $client_id." 涉嫌作弊，重复指令 => ".$value."\n";
                    Util::runtime(__CLASS__, __FUNCTION__, $start_time, 150);
                    return ;
                }
            } else {
                //$limit次内未出现，重新计数
                $checked[$value] = $value."|1|".$key;
            }
        }
        Util::runtime(__CLASS__, __FUNCTION__, $start_time, 150);
        return ;
    }

   /**
    * 当用户断开连接时触发
    * @param int $client_id 连接id
    */
   public static function onClose($client_id) {
       if(empty(self::$mGameRoleIds[$client_id])) return;
       $game_role_id = self::$mGameRoleIds[$client_id];
       if(array_key_exists($game_role_id, Events::$playerList))
       {
           if(Events::$playerList[$game_role_id]['online'] == false) return;
       }else
       {
           return;
       }
       self::exitGame($game_role_id);
       unset(self::$mGameRoleIds[$client_id]);
       unset(Events::$playerList[$game_role_id]);
       unset(Events::$user_list[$game_role_id]);
       Events::$mPlayerValues[$game_role_id] = null;
       unset(Events::$mPlayerValues[$game_role_id]);

       Timer::add(3, function($game_role_id){
           if(array_key_exists($game_role_id, Events::$playerList) == false) {
               return;
           }
           if( Events::$playerList[$game_role_id]['online'] == false)
           {
               unset(Events::$playerList[$game_role_id]);
           }
       }, [$game_role_id], false);

//       unset(self::$Public_data[$client_id]);
//       var_dump("$client_id logout\r\n");

       //Channel分布式通讯组件分组分发-----------------------------------------------------------
       /*
        * // 遍历连接加入的所有群组，从group_con_map删除对应的数据
        * if(isset(Events::$group_map)){
           foreach (Events::$group_map as $group_id => $c_ids) {
               unset(Events::$group_map[$group_id][$client_id]);
           }
           if(isset(Events::$group_con_map[$client_id])){
               unset(Events::$group_con_map[$client_id]);
           }
       }
       */
       //Channel分布式通讯组件分组分发-----------------------------------------------------------end

   }
   public static function exitGame($game_role_id){
       Rediss::$_redis->hSet("im_user_".$game_role_id,"status","offline"); //标记为下线
       //给好友发送下线通知，用来标记头像去除置亮
       $friend_lLen = Rediss::$_redis->lLen('im_user_friend_u'.$game_role_id);
       $friend_list = Rediss::$_redis->lRange('im_user_friend_u'.$game_role_id,0,$friend_lLen);
       $data = [
           "uid"   => $game_role_id,
           "status"=> 'offline'
       ];
       if(!empty($friend_list)){
           foreach ($friend_list as $v){
               if(Gateway::isUidOnline($v)){ //判断用户是否在线，用户在线推送好友上线消息
                   self::sendToFriend($v,Commads::$C1702,$data);
               }
           }
       }
       unset($friend_list);
       unset($data);
   }
    /**
     * 发送给自己
     * @param $game_role_id
     * @param $cmd
     * @param $vo
     */
    public static function sendToMy($game_role_id, $cmd, $vo, $isaround = 0){

        $client_id = Events::$playerList[$game_role_id]['client'];
        Gateway::sendToClient($client_id, Events::packMsg($cmd, $vo));
    }
    /**
     * 发送别人消息
     * @param $uid
     * @param $data
     */
    public static function sendToFriend($uid,$cmdid,$data){
        if (!Gateway::isUidOnline($uid)){
            //这里说明该用户已下线，日后做离线消息用
            if($cmdid != '1500'){
                $datas = [
                    'user_id'   => $uid,
                    'data'      => json_encode($data),
                ];
                //插入离线消息
                Rediss::$_redis->lPush("im_offline_message_".$uid,json_encode($datas));
            }
            return;
        }
        Gateway::sendToUid($uid,Events::packMsg($cmdid, $data));//发送消息
    }

    /**
     * 发送给自己错误消息
     * @param $game_role_id
     * @param $cmd
     * @param $vo
     */
    public static function sendToMyErrorMsg($game_role_id, $msg){
        $r['type'] = 10;
        $r['msg'] = $msg;
//        if($game_role_id == 0) {
//            self::sendToAll(Commads::$C1930, $r);
//        }else {
            self::sendToMy($game_role_id, Commads::$C1930, $r);
//        }

    }

    public static function packMsg($cmd, $data){
        if(self::$message_jsonopen) {
            return Events::packMsg_json($cmd, $data);
        }
    }

    public static function packMsg_json($cmd, $data){
        $vo['cmdid'] = $cmd;
        $vo['data'] = $data;
        $str = json_encode($vo);
        $code = strlen($str) . "^^^". $str;
        return $code;
    }
    /**
     * 将字符串转换成二进制
     */
    public static function StrToBin($str){
        //1.列出每个字符
        $arr = preg_split('/(?<!^)(?!$)/u', $str);
        //2.unpack字符
        foreach($arr as &$v){
            $temp = unpack('H*', $v);
            $v = base_convert($temp[1], 16, 2);
            unset($temp);
        }

        return join(' ',$arr);
    }
    /**
     * 将二进制转换成字符串
     */
    public static function BinToStr($str){
        $arr = explode(' ', $str);
        foreach($arr as &$v){
            $v = pack("H".strlen(base_convert($v, 2, 16)), base_convert($v, 2, 16));
        }
        return join('', $arr);
    }

    /**
     * js escape php 实现
     * @param $string           //the sting want to be escaped
     * @param $in_encoding
     * @param $out_encoding
     */
    public static function escape($string, $in_encoding = 'UTF-8',$out_encoding = 'UCS-2') {
        $return = '';
        if (function_exists('mb_get_info')) {
            for($x = 0; $x < mb_strlen ( $string, $in_encoding ); $x ++) {
                $str = mb_substr ( $string, $x, 1, $in_encoding );
                if (strlen ( $str ) > 1) { // 多字节字符
                    $return .= '%u' . strtoupper ( bin2hex ( mb_convert_encoding ( $str, $out_encoding, $in_encoding ) ) );
                } else {
                    $return .= '%' . strtoupper ( bin2hex ( $str ) );
                }
            }
        }
        return $return;
    }

    public static function unescape($str){
        $ret = '';
        $len = strlen($str);
        for ($i = 0; $i < $len; $i ++)
        {
            if ($str[$i] == '%' && $str[$i + 1] == 'u')
            {
                $val = hexdec(substr($str, $i + 2, 4));
                if ($val < 0x7f)
                    $ret .= chr($val);
                else
                    if ($val < 0x800)
                        $ret .= chr(0xc0 | ($val >> 6)) .
                            chr(0x80 | ($val & 0x3f));
                    else
                        $ret .= chr(0xe0 | ($val >> 12)) .
                            chr(0x80 | (($val >> 6) & 0x3f)) .
                            chr(0x80 | ($val & 0x3f));
                $i += 5;
            } else
                if ($str[$i] == '%')
                {
                    $ret .= urldecode(substr($str, $i, 3));
                    $i += 2;
                } else
                    $ret .= $str[$i];
        }
        return $ret;

        $str = rawurldecode($str);
        preg_match_all("/%u.{4}|&#x.{4};|&#d+;|.+/U",$str,$r);
        $ar = $r[0];
        foreach($ar as $k=>$v) {
            if(substr($v,0,2) == "%u")
                $ar[$k] = iconv("UCS-2","GBK",pack("H4",substr($v,-4)));
            elseif(substr($v,0,3) == "&#x")
                $ar[$k] = iconv("UCS-2","GBK",pack("H4",substr($v,3,-1)));
            elseif(substr($v,0,2) == "&#") {
                $ar[$k] = iconv("UCS-2","GBK",pack("n",substr($v,2,-1)));
            }
        }
        return join("",$ar);

        $ret = '';
        $len = strlen($str);
        for ($i = 0; $i < $len; $i++){
            if ($str[$i] == '%' && $str[$i+1] == 'u'){
                $val = hexdec(substr($str, $i+2, 4));
                    if ($val < 0x7f){
                        $ret .= chr($val);
                    } else if($val < 0x800) {
                        $ret .= chr(0xc0|($val>>6)).chr(0x80|($val&0x3f));
                    } else {
                        $ret .= chr(0xe0|($val>>12)).chr(0x80|(($val>>6)&0x3f)).chr(0x80|($val&0x3f));
                    }
                    $i = 5;
            } else if ($str[$i] == '%'){
                $ret .= urldecode(substr($str, $i, 3));
                $i = 2;
            } else {
                $ret .= $str[$i];
            }
        }
        return $ret;
    }
}
