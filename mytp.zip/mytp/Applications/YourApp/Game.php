<?php

use GatewayWorker\Lib\Gateway;
class Game extends BaseServices
{
    public function __construct(){
        self::listenSocketCmd(
            Commads::$C1700,
            Commads::$C1800,
            Commads::$C1703,
            Commads::$C1704,
            Commads::$C1705
        );
    }
    public function parseData($game_role_id, $cmdid, $msg){
        switch ($cmdid){
            case Commads::$C1700:
                self::GET1700($game_role_id,$msg);
                break;
            case Commads::$C1703:
                self::GET1703($game_role_id,$msg);
                break;
            case Commads::$C1704:
                self::GET1704($game_role_id,$msg);
                break;
            case Commads::$C1800:
                self::GET1800($game_role_id,$msg);
                break;
        }
    }
    public static function GET1700($game_role_id,$msg){
        $friend_id = $msg->to_user_id;
        $status = Rediss::$_redis->hGet("im_friend_".$game_role_id."_".$friend_id,"status");
        if($status == 0 && $status != false){
            $data = [
                'code' => 500,
                'msg'   => '对方已经是你的好友，不可重复添加'
            ];
            Gateway::sendToClient(Events::$mSelectRoleid[$game_role_id], Events::packMsg(Commads::$C1100, $data));
            unset($data);
            return;
        }
        if ($friend_id == $game_role_id){
            $data = [
                'code' => 500,
                'msg'   => '不能添加自己为好友'
            ];
            Gateway::sendToClient(Events::$mSelectRoleid[$game_role_id], Events::packMsg(Commads::$C1100, $data));
            unset($data);
            return;
        }
        $system_message = [
            'uid' => $game_role_id,
            'from_id' => $friend_id,
            'avatar' => Events::$user_list[$game_role_id]['avatar'],
            'nickname' => Events::$user_list[$game_role_id]['nickname'],
            'remark' => urldecode($msg->remark),
            'time' => time(),
            'type' => 0,
            'group_id' => $msg->to_friend_group_id,
            'status' => 0,
        ];
        Rediss::$_redis->hset("im_system_message_".$friend_id,time().mt_rand(1,100),json_encode($system_message));  //发个别人
        Rediss::$_redis->incr("im_system_message_count:".$friend_id);  //信息总数

        //获取该接受者未读消息数量
        $im_system_message_count = Rediss::$_redis->get("im_system_message_count:".$friend_id);
        if($im_system_message_count > 0){
            $re = [
                "count"     => $im_system_message_count
            ];
            Events::sendToFriend($friend_id,Commads::$C1500,$re);
        }
        unset($system_message);
        unset($im_system_message_count);
    }
    public static function GET1800($game_role_id,$msg){
        $id = $msg->id;//消息id
        $im_system_message_count = Rediss::$_redis->get("im_system_message_count:".$id);
        if($im_system_message_count > 0){
            $re = [
                "count"     => $im_system_message_count
            ];
            if(Gateway::isUidOnline($id)){
                Events::sendToFriend($id,Commads::$C1500,$re);
            }
        }
        unset($im_system_message_count);
    }
    public static function GET1703($game_role_id,$msg){
        if (isset($msg->to->type) && $msg->to->type == "friend") {
            //好友消息
            $data = [
                'username' => urldecode($msg->mine->username),
                'avatar' => $msg->mine->avatar,
                'id' => $msg->mine->id,
                'type' => $msg->to->type,
                'content' => urldecode($msg->mine->content),
                'cid' => 0,
                'mine'=> $game_role_id == $msg->to->id ? true : false,//要通过判断是否是我自己发的
                'fromid' => $msg->mine->id,
                'timestamp' => time()*1000
            ];
            if ($msg->to->id == $game_role_id) {
                return;
            }
            $safecheck = self::checktxtsafe($game_role_id, urldecode($msg->mine->content));
            if($safecheck == 'danger') {
                Events::sendToMyErrorMsg($game_role_id, '该聊天带有敏感内容!如发送广告内容会被系统禁言');
                return;
            }
            Events::sendToFriend($msg->to->id,Commads::$C1703,$data);
            $im_user = Rediss::$_redis->hGetAll("im_user_".$game_role_id);
            $record_data = [
                'username'       => $im_user['nickname'],
                'id'       => $im_user['user_id'],
                'avatar'     => $im_user['avatar'],
                'content'       => $msg->mine->content,
                'timestamp'    => time()
            ];
            //记录聊天记录
            Rediss::$_redis->rPush("im_chat_record_u".$game_role_id."_f".$msg->to->id,json_encode($record_data));
            unset($record_data);
            unset($data);
        } elseif (isset($msg->to->type) && $msg->to->type == "group") {
            //群消息
            $data = [
                'username' => urldecode($msg->mine->username),
                'avatar' => $msg->mine->avatar,
                'id' => $msg->to->id,
                'type' => $msg->to->type,
                'content' => urldecode($msg->mine->content),
                'cid' => 0,
                'mine'=> false,//要通过判断是否是我自己发的
                'fromid' => $msg->mine->id,
                'timestamp' => time()*1000
            ];
            $list = Rediss::$_redis->sMembers("im_qun_group_number_".$msg->to->id);
            foreach ($list as $v) {
                if ( $v == $msg->mine->id) {
                    continue;
                }
                var_dump($v);
                Events::sendToFriend($v,Commads::$C1703,$data);
            }
            //记录聊天记录
            $im_user = Rediss::$_redis->hGetAll("im_user_".$game_role_id);
            $record_data = [
                'username'       => $im_user['nickname'],
                'id'       => $im_user['user_id'],
                'avatar'     => $im_user['avatar'],
                'content'       => $msg->mine->content,
                'timestamp'    => time()
            ];
            //记录聊天记录
            Rediss::$_redis->rPush("im_chat_record_g".$msg->to->id,json_encode($record_data));
        }
    }
    public static function GET1705($game_role_id, $msg){
        //加群提醒
        $groupid = $msg->groupid;
        $list = Rediss::$_redis->sMembers("im_qun_group_number_".$groupid);
        $data = [
            "system"    => true,
            "id"        => $groupid,
            "type"      => "group",
            "content"   => Events::$user_list[$game_role_id]['nickname']."加入了群聊，欢迎下新人吧～"
        ];
        foreach ($list as $v) {
            Events::sendToFriend($v,Commads::$C1705,$data);
        }
       unset($list);
       unset($data);
    }
    //内容检查
    public static function checktxtsafe($game_role_id, $msg) {
        if(strpos($msg, "[color=#") !== false) return;
        $response = self::Action_Moderation($msg);
        if(empty($response['Label']) || is_array($response) == false) return;
        if($response['Label'] != 'Normal')  //Normal：正常，Porn：色情，Abuse：谩骂，Ad：广告，Custom：自定义违规
        {
            if($response['Label'] == 'Ad' && $game_role_id > 0)
            {
                $add = Events::getValue($game_role_id, 'gag_times') + 1;
                Events::setValue($game_role_id, 'gag_times', $add, false, $msg);
                if($add >= 5) {
                    Events::setValue($game_role_id, 'gag', 1, false, '打广告');
                }
            }
            return 'danger';
        }
    }
    /**
     * 文本内容安全检测
     */
    public static function Action_Moderation($content)
    {
        $content = base64_encode($content);
        $Action = 'TextModeration';
        $Version = '2020-12-29';
        $Region = 'ap-guangzhou';
        $Timestamp = time();
        $BizType = 'normal';
        $Nonce = mt_rand(1, 99999999);
        $SecretId = "AKIDfDa1aI4jxBKd2PitLeK60nneJnPzs8Cp";
        $secretKey = "hnGQQR3SkIiwZ7azNLEOPKUnLo9kXz74";
        $param["Action"] = $Action;
        $param["Region"] = $Region;
        $param["Timestamp"] = $Timestamp;
        $param["Nonce"] = $Nonce;
        $param["SecretId"] = $SecretId;
        $param["Version"] = $Version;
        $param["Content"] = $content;
        $param["BizType"] = $BizType;
        ksort($param);
        $signStr = "GETtms.tencentcloudapi.com/?";
        foreach ( $param as $key => $value ) {
            $signStr = $signStr . $key . "=" . $value . "&";
        }
        $signStr = substr($signStr, 0, -1);
        $Signature = base64_encode(hash_hmac("sha1", $signStr, $secretKey, true));
        $Signature = urlencode($Signature);
        $content = urlencode($content);
        $url = 'https://tms.tencentcloudapi.com/?Action='.$Action.'&Content='.$content.'&Action='.$Action.'&Version='.$Version.
            '&Region='.$Region.'&Timestamp='.$Timestamp.'&Nonce='.$Nonce.'&SecretId='.$SecretId.'&Signature='.$Signature.'&BizType='.$BizType;
        $data = file_get_contents($url);
        $data1 = json_decode($data, 1);
        return $data1['Response'];

        if (!$content) {
            return json_encode(array('status' => false, 'Code' => 404));
        }
        if (!is_string($content)) {
            return json_encode(array('status' => false, 'Code' => 500, 'message' => '参数有误'));
        }
        $pattern = '/企\s+鹅|哲\s+扣/';
        preg_match_all($pattern, $content, $result);
        if (!empty($result[0])) {
            $keys = [];
            $keys['EvilFlag'] = 1;
            $keys['EvilType'] = 20105;
            foreach ($result[0] as $key => $value) {
                $keys['Keywords'][] = preg_replace("/\s/", '', $value);
            }

            return (json_encode(array('data' => $keys)));
        }
        $content = base64_encode($content);
        $array = [
            'Content' => $content
        ];
        $payload = json_encode($array);
        $response = self::tc_curl('TextModeration', $payload);
        $res = json_decode($response, true);
         var_dump($res);
        if (isset($res['Response']['Error'])) {
            $message = $res['Response']['Error']['Message'];
            return json_encode(array('status' => false, 'Code' => $res['Response']['Error']['Code'], 'message' => $message));
        }
//        var_dump($response);exit();
        return (json_encode(array('data' => $res['Response']['Data'])));
    }

    /**
     * 设置选项协议通信
     * @param $action
     * @param $payload
     * @return bool|string
     */
    public static function tc_curl($action, $payload)
    {

        $params = self::signature_post($action, $payload);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, 'https://' . $params['host'] . $params['canonicalUri'] . $params['canonicalQueryString']);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $params['httpRequestMethod']);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_HEADER, FALSE);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            "Authorization: " . $params['authorization'],
            "Content-Type:application/json; charset=utf-8",
            "Host: " . $params['host'],
            "X-TC-Action: " . $params['action'],
            "X-TC-Timestamp: " . $params['timestamp'],
            "X-TC-Version: " . $params['version'],
            "X-TC-Region: " . $params['region']
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $payload);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }
    /**
     * 文本内容POST请求参数签名
     * @param $action
     * @param $payload
     * @return array
     */
    public static function signature_post($action, $payload)
    {

        $secretId = "AKIDfDa1aI4jxBKd2PitLeK60nneJnPzs8Cp";
        $secretKey = "hnGQQR3SkIiwZ7azNLEOPKUnLo9kXz74";
        $host = "cms.tencentcloudapi.com";
        $service = "cms";
        $version = "2019-03-21";
        $region = "ap-guangzhou";
        $timestamp = time();
        $algorithm = "TC3-HMAC-SHA256";

        $httpRequestMethod = "POST";
        $canonicalUri = "/";
        $canonicalQueryString = "";
        $canonicalHeaders = "content-type:application/json; charset=utf-8\n" . "host:" . $host . "\n";
        $signedHeaders = "content-type;host";
//        $payload = '{"Limit": 1, "Filters": [{"Values": ["\u672a\u547d\u540d"], "Name": "instance-name"}]}';

// step 1: build canonical request string
        $hashedRequestPayload = hash("SHA256", $payload);
        $canonicalRequest = $httpRequestMethod . "\n"
            . $canonicalUri . "\n"
            . $canonicalQueryString . "\n"
            . $canonicalHeaders . "\n"
            . $signedHeaders . "\n"
            . $hashedRequestPayload;

// step 2: build string to sign
        $date = gmdate("Y-m-d", $timestamp);
        $credentialScope = $date . "/" . $service . "/tc3_request";
        $hashedCanonicalRequest = hash("SHA256", $canonicalRequest);
        $stringToSign = $algorithm . "\n"
            . $timestamp . "\n"
            . $credentialScope . "\n"
            . $hashedCanonicalRequest;

// step 3: sign string
        $secretDate = hash_hmac("SHA256", $date, "TC3" . $secretKey, true);
        $secretService = hash_hmac("SHA256", $service, $secretDate, true);
        $secretSigning = hash_hmac("SHA256", "tc3_request", $secretService, true);
        $signature = hash_hmac("SHA256", $stringToSign, $secretSigning);


// step 4: build authorization
        $authorization = $algorithm
            . " Credential=" . $secretId . "/" . $credentialScope
            . ", SignedHeaders=content-type;host, Signature=" . $signature;

        return $result = [
            'action' => $action,
            'version' => $version,
            'region' => $region,
            'timestamp' => $timestamp,
            'httpRequestMethod' => $httpRequestMethod,
            'canonicalUri' => $canonicalUri,
            'canonicalQueryString' => $canonicalQueryString,
            'authorization' => $authorization,
            'host' => $host,
            'payload' => $payload
        ];


    }

    public static function GET1704($game_role_id,$msg){
        $user = Events::$user_list[$game_role_id];

        //对方
        $all =Rediss::$_redis->hGetAll('im_user_'.$msg->id);
        //系统消息
        $system_message_data = [
            'uid' => $msg->id,
            'from_id' => $game_role_id,
            'nickname' => $all['nickname'],
            'remark' => "同意你好友",
            'time' => time(),
            'type' => 1,        //系统消息
            'status' => 1,      //1'同意' - 2'拒绝'
        ];
        Rediss::$_redis->hset("im_system_message_".$msg->id,time().mt_rand(1,100),json_encode($system_message_data));
        Rediss::$_redis->incr("im_system_message_count:".$msg->id);

        $stuts = 'offline';
        //对方如果在线追加好友到好友列表
        if(Gateway::isUidOnline($msg->id)){
            $stuts = 'online';
            $data = [
                "type"  => "friend",
                "avatar"    => $user['avatar'],
                "username" => $user['nickname'],
                "groupid" => $msg->fromgroup,
                "id"        => $user['user_id'],
                "sign"    => $user['sign'],
                'status' => "online"
            ];
            //获取未读消息盒子数量
            $count = Rediss::$_redis->get("im_system_message_count:".$msg->sessionid);
            $data1 = [
                "count"     => $count
            ];
            Events::sendToFriend($msg->id,Commads::$C1704,$data);
            Events::sendToFriend($msg->id,Commads::$C1500,$data1);
        }
        //自己列表追加好友列表
        $friend_group_id = Rediss::$_redis->hGet("im_friend_".$game_role_id."_".$msg->id,"friend_group_id");
        $data = [
            "type"  => "friend",
            "avatar"    => $all['avatar'],
            "username" => $all['nickname'],
            "groupid" => $friend_group_id,
            "id"        => $all['user_id'],
            "sign"    => $all['sign'],
            'status' => $all['status']
        ];
        Events::sendToFriend($game_role_id,Commads::$C1704,$data);
        unset($data);
        unset($data1);
        unset($all);
        unset($stuts);
        unset($friend_group_id);
        unset($system_message_data);
    }
}