<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */
use Workerman\Worker;
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../Channel/Server.php';
//Tcp 通讯方式
$path = 'config.ini';
$config = parse_ini_file( __DIR__ . "/../../" . $path, true);
$channel_server = new Channel\Server($config['channel_ip'], $config['channel_port']);

//Unix Domain Socket 通讯方式
//$channel_server = new Channel\Server('unix:///tmp/workerman-channel.sock');

if(!defined('GLOBAL_START'))
{
    Worker::runAll();
}
