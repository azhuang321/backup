<?php


class Commads {
    //登录协议
    public static $C1411 = 1411;
    //提示协议
    public static $C1100 = 1100;
    //消息盒子
    public static $C1500 = 1500;

    //添加好友
    public static $C1700 = 1700;
    //添加群
    public static $C1701 = 1701;
    //好友上下线变更
    public static $C1702 = 1702;
    //聊天
    public static $C1703 = 1703;

    //将刚通过的好友追加到好友列表
    public static $C1704 = 1704;

    public static $C1705 = 1705;

    //拒绝添加好友
    public static $C1800 = 1800;

    //全局错误信息
    public static $C1930 = 1930;



    /** 变量数据 */
    public static $data_value = 'value';

    /** 玩家范圍 */
    public static $IDBegin_cache_player = 500000;

    /** 跨服玩家范圍 */
    public static $IDBegin_cache_crossplayer = 200000000;

    /** 角色數據 */
    public static $data_role = 'role';
}