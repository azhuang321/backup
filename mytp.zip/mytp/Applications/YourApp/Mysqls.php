<?php

use think\facade\Db;
use Workerman\Lib\Timer;
class Mysqls
{
    public static $mysql = false;
    public function __construct(){
        if(!Mysqls::$mysql){
            $config = Events::$public_config;
            Db::setConfig([
                // 默认数据连接标识
                'default'     => 'mysql',
                // 数据库连接信息
                'connections' => [
                    'mysql' => [
                        // 数据库类型
                        'type'     => 'mysql',
                        // 主机地址
                        'hostname' => $config['mysql_hostname'],
                        // 用户名
                        'username' => $config['mysql_username'],
                        // 数据库密码
                        'password'    => $config['mysql_password'],
                        // 数据库连接端口
                        'hostport'    => $config['mysql_hostport'],
                        // 数据库名
                        'database' => $config['mysql_database'],
                        // 数据库编码默认采用utf8
                        'charset'  => 'utf8',
                        // 数据库表前缀
                        'prefix'   => $config['mysql_prefix'],
                        // 数据库调试模式
                        'debug'    => true,
                    ],
                ],
            ]);
            Mysqls::$mysql = true;
        }
        Timer::add(55, function (){
            // 定时发送select 1 语句作为心跳
            Db::query('select 1 limit 1');
        });
    }

    public function admin_info(){
        return Db::name("admin")->select();
    }
}