<?php
class Tally extends BaseServices {
    /** 服务器id */
    public $m_server_id;
    public function __construct()
    {
        self::listenSocketCmd(
        );

        $this->init();
    }
    public function init(){
        $config = Events::$public_config;
        $this->m_server_id = $config['server_id'];
    }
}