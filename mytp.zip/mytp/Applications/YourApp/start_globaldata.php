<?php
use Workerman\Worker;
//require_once __DIR__ . '/../../Workerman/Autoloader.php';
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../GlobalData/Server.php';
$path = 'config.ini';
$config = parse_ini_file( __DIR__ . "/../../" . $path, true);
$worker = new GlobalData\Server($config['globalData_ip'], $config['globalData_port']);
Worker::runAll();