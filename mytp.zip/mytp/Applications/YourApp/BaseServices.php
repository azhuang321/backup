<?php


class BaseServices {
    public function listenSocketCmd(...$args){
        foreach($args as $value) {
            GOperation::regist('s_' . $value, array($this, 'parseData'));
        }
    }

    public function parseData($client_id, $cmdid, $msg){

    }
}