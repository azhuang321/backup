<?php
use Workerman\Worker;
require_once __DIR__.'/../../vendor/workerman/workerman/Autoloader.php';

// 创建一个Worker监听2345端口，使用http协议通讯
$http_worker = new Worker("http://0.0.0.0:2345");

// 启动4个进程对外提供服务
$http_worker->count = 4;

// 接收到浏览器发送的数据时回复hello world给浏览器
$http_worker->onMessage = function($connection, $request) {
    //获取host
//    $connection->send($request->host());
//    //获取请求方法
//    $connection->send($request->method());
//    //获取请求uri
//    $connection->send($request->uri());
//    //获取请求路径
    $connection->send($request->path());
//    //获取请求queryString
//    $connection->send($request->queryString());
//    //获取请求HTTP版本
//    $connection->send($request->protocolVersion());
//    //获取请求sessionId
//    $connection->send($request->sessionId());
};

// 运行worker
Worker::runAll();
