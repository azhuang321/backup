<?php
/**
 * Created by PhpStorm.
 * User: kangkang
 * Date: 2021/7/8
 * Time: 23:34
 */

namespace app\api\middleware;


class ApiToken
{

    /**
     * 处理请求
     *
     * @param \think\Request $request
     * @param \Closure       $next
     * @return Response
     */
    public function handle($request, \Closure $next)
    {
        $token = $request::header("token");
        if($token){

        }else{
            $request->JwtAuth = 1;
        }
        return $next($request);
    }
}