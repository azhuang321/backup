<?php
declare (strict_types = 1);

namespace app\api\middleware;

use app\api\common\JwtAuth as Api_JwtAuth;
use think\facade\Request;

class JwtAuth
{
    /**
     * 处理请求
     *
     * @param \think\Request $request
     * @param \Closure       $next
     * @return Response
     */
    public function handle($request, \Closure $next)
    {
        $token = Request::header("token");
        if($token){
            if(count(explode(".",$token)) <> 3){
                $request->JwtAuth = 1;
            }

            //获取JwtAuth的句柄
            $jwtAuth = Api_JwtAuth::getInstance();

            //设置token
            $jwtAuth->setToken($token);

            //验证token
            if($jwtAuth->validate() && $jwtAuth->verify()){
                return $next($request);
            }else{
                $request->JwtAuth = 1;
            }
        }else{
            $request->JwtAuth = 1;
        }
        return $next($request);
    }

    public function result($array=[],$code=200,$msg="success"){
        return json_encode(["code"=>$code,"msg"=>$msg,"data"=>$array]);
    }
}
