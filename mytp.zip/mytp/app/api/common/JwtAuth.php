<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2021/3/29 0029
 * Time: 15:20
 */

namespace app\api\common;



use Lcobucci\JWT\Builder;
use Lcobucci\JWT\Parser;
use Lcobucci\JWT\Signer\Hmac\Sha256;
use Lcobucci\JWT\ValidationData;

/**
 *  * 单例 一次请求中所有出现jwt的地方都是一个用户
*  * Class JwtAuth
*  * @package app\api\common
*  */
class JwtAuth
{
    /**
     *
     * WT指定了七个默认claims字段供选择。
        iss：发行人
        sub：主题
        aud：用户
        exp：到期时间
        nbf：在此之前不可用
        iat：发布时间
        jti：JWT ID用于标识该JWT
     *
     */
    /**
     * JWT TOKEN
     * @var [type]
     */
    private $token;

    //jwt过期时间
    private $expTime = 3600;


    /**
     * 颁发
     * @var string
     */
    private $iss = 'api.test.com';
    /**
     * 接收
     * @var string
     */
    private $aud = 'app.com';

    private $uid;

    private $secrect="#$%#$%*&^(*(*(";

    private $decodeToken;

    private static $instance;

    //获取JwtAuth的句柄
    public static function getInstance() {
        if(is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __contruct(){

    }

    private function __clone(){

    }

    public function encode(){
        $time = time();
        $this->token = (new Builder())->setHeader('alg','HS256')
            ->setIssuer($this->iss)
            ->setAudience($this->aud)
            ->setIssuedAt($time) //生效时间
            ->setExpiration($time + $this->expTime)//过期时间
            ->set('uid',$this->uid)
            ->sign(new Sha256(), $this->secrect)//加密算法
            ->getToken();
        return $this;
    }

    public function getToken(){
        return (string)$this->token;
    }

    public function setExpTime($time){
        $this->expTime = $time;
        return $this;
    }
    public function setToken($token){
        $this->token = $token;
        return $this;
    }
    /**
     * 用户信息uid
     * @param [type] $uid [description]
     */
    public function setUid($uid){
        $this->uid = $uid;
        return $this;
    }
    public function getUid(){
        return $this->uid;
    }

    public function jsonDecode(){

        $token = $this->token;
        $this->decodeToken = (new Parser())->parse((string) $token);

        // echo $this->decodeToken->getClaim('uid');
        return $this->decodeToken;
    }
    public function decdoe(){
        if(!$this->decodeToken){
            $this->decodeToken = (new Parser())->parse((string)$this->token);
            $this->uid = $this->decodeToken->getClaim('uid');
        }
        return $this->decodeToken;
    }
    /**
     * 验证令牌是否有效
     * @return [type] [description]
     */
    public function validate(){
        $data = new ValidationData();
        $data->setIssuer($this->iss);
        $data->setAudience($this->aud);
        return $this->jsonDecode()->validate($data);
    }
    /**
     * 签名来验证令牌在生成后是否未被改
     * @return [type] [description]
     */
    public function verify(){
        $result = $this->jsonDecode()->verify(new Sha256(), $this->secrect);
        return $result;
    }

}