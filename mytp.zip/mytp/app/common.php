<?php
// 应用公共文件
use app\admin\model\LogModel;

//success
function renderSuccess(string $msg = '', string $url = '', array $data = []){
    return renderJson(200,$msg,$url,$data);
}
function renderJson(int $code = 0, string $msg = '', string $url = '' , array $data = []){
    return json(compact('code', 'msg', 'url', 'data'));
}
function renderError(string $msg = '', string $url = '', array $data = []){
    return renderJson(500,$msg,$url,$data);
}


function get_redis_object_do(array $config){
    if(empty($config)){
        $config = array(
            'host'=> "127.0.0.1",
            'port'=> "6379",
            'auth' => "123456",
        );
    }
    $redis =  \Lib\Redis::getInstance($config, array('db_id'=>1,'timeout' => 60 ));
    return $redis;
}

/**
 * 生成密码hash值
 * @param $password
 * @return string
 */
function study_hash($password)
{
    return md5(md5($password) . 'study_salt_SmTRx');
}

/**
 * 记录日志
 * @param  [type] $uid         [用户id]
 * @param  [type] $username    [用户名]
 * @param  [type] $description [描述]
 * @param  [type] $status      [状态]
 */

function writelog($uid,$username,$description,$status)
{

    $data['admin_id'] = $uid;
    $data['admin_name'] = $username;
    $data['description'] = $description;
    $data['status'] = $status;
    $data['ip'] = request()->ip();
    $data['add_time'] = time();
    LogModel::create($data);

}
/**
 * 整理菜单树方法
 */
function prepareMenu($param)
{
    $parent = []; //父类
    $child = [];  //子类

    foreach($param as $key=>$vo){

        if($vo['pid'] == 0){
            $vo['href'] = '#';
            $parent[] = $vo;
        }else{
            $vo['href'] = url($vo['name']); //跳转地址
            $child[] = $vo;
        }
    }

    foreach($parent as $key=>$vo){
        foreach($child as $k=>$v){

            if($v['pid'] == $vo['id']){
                $parent[$key]['child'][] = $v;
            }
        }
    }
    unset($child);
    return $parent;
}
/**
 * 循环删除目录和文件
 * @param string $dir_name
 * @return bool
 */
function delete_dir_file($dir_name){
    $result = false;
    if(is_dir($dir_name)){
        if($handle = opendir($dir_name)){
            while(false !== ($item = readdir($handle))){
                if($item != "." && $item != ".."){
                    if(is_dir($dir_name.'/'.$item)){
                        delete_dir_file($dir_name.'/'.$item);
                    }else{
                        unlink($dir_name.'/'.$item);
                    }
                }
            };
            closedir($handle);
            if(rmdir($dir_name)){
                $result = true;
            }
        }
    }
    return $result;
}

/**
 * 打印调试函数
 * @param $content
 * @param $is_die
 */
function pre($content, $is_die = true)
{
    header('Content-type: text/html; charset=utf-8');
    echo '<pre>' . print_r($content, true);
    $is_die && die();
}

/**管理员角色
 * @param $val
 * @return mixed|string
 */
function getGroupName($val){
    if($val){
        return \app\admin\model\UserType::where('id',$val)->value('title');
    }else{
        return '';
    }
}


/**
七牛云上传方法
@param file_path 本地文件的绝对路径
@param new_file_name 上传到七牛上保存的文件名称,一般不要Uploads/image  下面的层次
 **/
function save_image_to_qiniu($file_path,$new_file_name)
{
    try{
        include_once  ROOT_PATH . 'extend/Lib/Qiniu/autoload.php';
        //qiniu_accesskey
        $accessKey_arr =  "t5GwERhGf--HWOMVDB8nYRKveB9-sWq_bu7-ABqZ";
        $secretKey_arr =  "rESkzCDixs98Zjo0XIFMCIlZZpUsJDDpODl2slO2";
        $bucket_arr =  "xinshilihgb";
        $accessKey = $accessKey_arr;
        $secretKey = $secretKey_arr;
        $bucket = $bucket_arr;
        $auth = new \Qiniu\Auth($accessKey, $secretKey);
        // 生成上传 Token
        $token = $auth->uploadToken($bucket);
        $filePath = $file_path;
        // 上传到七牛后保存的文件名
        $key = $new_file_name;//'Uploads/2.jpg';
        // 初始化 UploadManager 对象并进行文件的上传。
        $uploadMgr = new \Qiniu\Storage\UploadManager();
        // 调用 UploadManager 的 putFile 方法进行文件的上传。
        list($ret, $err) = $uploadMgr->putFile($token, $key, $filePath);
        if ($err !== null) {
            return array('code' => 1, 'msg' => '七牛云上传失败');
        } else {
            return array('code' => 0, 'key' => $ret['key']);
        }
    }catch(\think\Exception $exception){
        return array('code' => 1, 'msg' => $exception->getMessage());
    }
}
function tomedia_qiniu(string $img_url, string $bucket){
    switch ($bucket){
        case "artea":
            return "http://qvvt4drer.hn-bkt.clouddn.com/".$img_url;
        case "xinshilihgb":
            return "http://qwwb4jl5n.hn-bkt.clouddn.com/".$img_url;
        default:
            return "http://qwwb4jl5n.hn-bkt.clouddn.com/";
    }
}
if (!function_exists("getValidate")) {
    function getValidate($w, $h, $key)
    {
        ob_start();
        $img = imagecreatetruecolor($w, $h);
        $gray = imagecolorallocate($img, 255, 255, 255);
        $black = imagecolorallocate($img, rand(0, 200), rand(0, 200), rand(0, 200));
        $red = imagecolorallocate($img, 255, 0, 0);
        $white = imagecolorallocate($img, 255, 255, 255);
        $green = imagecolorallocate($img, 0, 255, 0);
        $blue = imagecolorallocate($img, 0, 0, 255);
        imagefilledrectangle($img, 0, 0, 210, 70, $black);
        for ($i = 0; $i < 80; $i++) {
            imagesetpixel($img, rand(0, $w), rand(0, $h), $gray);
        }
        $num1 = mt_rand(51, 100);
        $num2 = mt_rand(1, 50);
        $rand = getRand();
        $ttf = base_path('../public/static/asset/Moderan.ttf');
        imageTtfText($img, 20, rand(-45, 45), 20, rand(30, 50), $red, $ttf, $num1);
        imageTtfText($img, 20, 0, 65, rand(30, 50), $white, $ttf, $rand);
        imageTtfText($img, 20, rand(-45, 45), 100, rand(30, 50), $green, $ttf, $num2);
        imageTtfText($img, 20, 0, 135, rand(30, 50), $blue, $ttf, "=");
        imageTtfText($img, 20, 0, 185, rand(30, 50), $red, $ttf, "?");
        imagepng($img);
        imagedestroy($img);
        $content = ob_get_clean();
        if ($rand == "+") {
            //加
            $result = $num1 + $num2;
        } else {
            //减
            $result = $num1 - $num2;
        }
//        $expiresAt = \Carbon\Carbon::now()->addMinutes(2);
//        \Illuminate\Support\Facades\Cache::put('image:' . $key, $result, $expiresAt);
        return response($content)->header('Content-Type', 'image/png');
    }
}

if(!function_exists('getRand')){
    function getRand(){
        $code = mt_rand(0,1);
        switch ($code) {
            case 0:
                return "+";
                break;
            case 1:
                return "-";
                break;
            default:
                # code...
                break;
        }
    }
}
if(!function_exists('time_tranx')){
    function time_tranx($the_time){
        $now_time = time();
        $dur = $now_time - $the_time;
        if($dur <= 0){
            return '刚刚';
        }else{
            if($dur < 60){
                return $dur.'秒前';
            }else{
                if($dur < 3600){
                    return floor($dur/60).'分钟前';
                }else{
                    if($dur < 86400){
                        return floor($dur/3600).'小时前';
                    }else{
                        if($dur < 259200){ //3天内
                            return floor($dur/86400).'天前';
                        }else{
                            return date("Y-m-d H:i:s",$the_time);
                        }
                    }
                }
            }
        }
    }
}

/**
 * js escape php 实现
 * @param $string           //the sting want to be escaped
 * @param $in_encoding
 * @param $out_encoding
 */
function escape($string, $in_encoding = 'UTF-8',$out_encoding = 'UCS-2') {
    $return = '';
    if (function_exists('mb_get_info')) {
        for($x = 0; $x < mb_strlen ( $string, $in_encoding ); $x ++) {
            $str = mb_substr ( $string, $x, 1, $in_encoding );
            if (strlen ( $str ) > 1) { // 多字节字符
                $return .= '%u' . strtoupper ( bin2hex ( mb_convert_encoding ( $str, $out_encoding, $in_encoding ) ) );
            } else {
                $return .= '%' . strtoupper ( bin2hex ( $str ) );
            }
        }
    }
    return $return;
}

function unescape($str){
    $ret = '';
    $len = strlen($str);
    for ($i = 0; $i < $len; $i ++)
    {
        if ($str[$i] == '%' && $str[$i + 1] == 'u')
        {
            $val = hexdec(substr($str, $i + 2, 4));
            if ($val < 0x7f)
                $ret .= chr($val);
            else
                if ($val < 0x800)
                    $ret .= chr(0xc0 | ($val >> 6)) .
                        chr(0x80 | ($val & 0x3f));
                else
                    $ret .= chr(0xe0 | ($val >> 12)) .
                        chr(0x80 | (($val >> 6) & 0x3f)) .
                        chr(0x80 | ($val & 0x3f));
            $i += 5;
        } else
            if ($str[$i] == '%')
            {
                $ret .= urldecode(substr($str, $i, 3));
                $i += 2;
            } else
                $ret .= $str[$i];
    }
    return $ret;

    $str = rawurldecode($str);
    preg_match_all("/%u.{4}|&#x.{4};|&#d+;|.+/U",$str,$r);
    $ar = $r[0];
    foreach($ar as $k=>$v) {
        if(substr($v,0,2) == "%u")
            $ar[$k] = iconv("UCS-2","GBK",pack("H4",substr($v,-4)));
        elseif(substr($v,0,3) == "&#x")
            $ar[$k] = iconv("UCS-2","GBK",pack("H4",substr($v,3,-1)));
        elseif(substr($v,0,2) == "&#") {
            $ar[$k] = iconv("UCS-2","GBK",pack("n",substr($v,2,-1)));
        }
    }
    return join("",$ar);

    $ret = '';
    $len = strlen($str);
    for ($i = 0; $i < $len; $i++){
        if ($str[$i] == '%' && $str[$i+1] == 'u'){
            $val = hexdec(substr($str, $i+2, 4));
            if ($val < 0x7f){
                $ret .= chr($val);
            } else if($val < 0x800) {
                $ret .= chr(0xc0|($val>>6)).chr(0x80|($val&0x3f));
            } else {
                $ret .= chr(0xe0|($val>>12)).chr(0x80|(($val>>6)&0x3f)).chr(0x80|($val&0x3f));
            }
            $i = 5;
        } else if ($str[$i] == '%'){
            $ret .= urldecode(substr($str, $i, 3));
            $i = 2;
        } else {
            $ret .= $str[$i];
        }
    }
    return $ret;
}

