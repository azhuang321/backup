<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2021/3/29 0029
 * Time: 16:42
 */

namespace app\controller;

use app\BaseController;

class Task{
    public function task_index(){
       echo "task now".PHP_EOL;
    }
}