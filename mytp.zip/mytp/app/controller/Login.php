<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2021/3/29 0029
 * Time: 16:42
 */

namespace app\controller;

use app\api\common\JwtAuth;
use app\BaseController;

class Login extends BaseController{
    public function lanr(){
        //获取JwtAuth的句柄
        $jwtauth = JwtAuth::getInstance();

        //生成token
        $token =$jwtauth->setUid(1)->encode()->getToken();
        return $token;
//        cookie("token",$token,3600);
//        return "lanr";
    }
    public function index(){
        dump($this->lanr());
        
        return "index";
    }
}