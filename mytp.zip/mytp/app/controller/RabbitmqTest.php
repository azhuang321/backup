<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2021/3/29 0029
 * Time: 16:42
 */

namespace app\controller;


use app\BaseController;
use Lib\DelayQueue;
class RabbitmqTest extends BaseController{

    public function index(){
        $delay = new DelayQueue();
        $ttl            =  100000;//订单100s后超时
        $delayExName    = 'order_exchange';//超时exchange
        $delayQueueName = 'order-queue';//超时queue
        $queueName      = 'ttl-queue';//订单queue
        
        $delay->createQueue($ttl, $delayExName, $delayQueueName, $queueName);
        // //100个订单信息，每个订单超时时间都是10s
        for ($i = 0; $i < 2; $i++) {
            $data = [
                'order_id' => $i + 1,
                'remark'   => 'this is a order test'
            ];
            $delay->sendMessage(json_encode($data), $queueName);
            // sleep(10);
        }
        
    }
    public function index2(){
        //////////////////////////////////
        // 消费者
        $delay = new DelayQueue();
        $delayQueueName = 'order-queue';
        $callback = function ($msg) {
            echo $msg->body . PHP_EOL;
            $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
        
            //处理订单超时逻辑，给用户推送提醒等等。。。
            // sleep(10);
        };
        /**
         * 消费已经超时的订单信息，进行处理
         */
         while(true){
            $delay->consumeMessage($delayQueueName, $callback);
            sleep(2);
            $this->index2();
        }
    }
}