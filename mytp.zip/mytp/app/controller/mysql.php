<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2021/3/29 0029
 * Time: 16:42
 */

namespace app\controller;

use app\api\common\JwtAuth;
use app\BaseController;
use think\facade\Db;

class mysql extends BaseController{

    public function add(){
        $data = [];
        for($i=0;$i<5;$i++){
            array_push($data,['name'=>'name2_'.($i+1)]);
        }
        $res = Db::name("config")->insertAll($data);       //主库
        dump('插入成功条数:' . $res);
    }

    public function list(){
        $res = Db::table('student')->where('id','=',1)->find();  //从库
        dump($res);
        $row = Db::table('student')->where('id','=',$res['id'])->update(['name' => 'name_4']);  //主库
        echo $row;

        // 在配置中 开启自动主库读取
        //'read_master' => true,
        //$res2 = Db::table('student')->where('id','=',1)->find(); //主库


        $res2 = Db::table('student')->where('id','=',1)->master(true)->find(); //主库
        dump($res2);
    }
}