<?php


namespace app\layim\model;


use app\admin\controller\CacheService;
use think\cache\driver\Redis;
use think\facade\Db;
use think\Model;

class ImUserModel extends Model {
    protected $table = "study_im_user";

    public static $redis;
    public function __construct() {
        $config = array(
            'host'=> "127.0.0.1",
            'port'=> "6379",
            'auth' => "",
        );
        self::$redis = get_redis_object_do($config);
    }

    public static function login(array $data, string $type){
        try{
            $adminInfo = self::verifyLogin($data['username'], $data['password']);
            $exptime = 3600;
            CacheService::createToken($adminInfo['user_id'], $exptime, $type,"token_layim");
//            writelog($adminInfo['user_id'], $adminInfo['username'], 'layim用户【' . $adminInfo['username'] . '】登录成功', 1);
        }catch (\Exception $e){
            // 这是进行异常捕获
            return ["code"=>"500","msg"=>$e->getMessage()];
        }

    }
    public static function verifyLogin(string $user_name, string $password){
        $hash_pwd = study_hash($password);
        $user_info = array();
        $user_id = self::$redis->hGet("im_user_info",$user_name);
        if(!$user_id){
            throw new \think\Exception('管理员不存在', 10006);
        }
        $im_user_name = self::$redis->hMget("im_user_".$user_id,"username");
        if($im_user_name['username'] == $user_name){
            $im_user_pwd = self::$redis->hMget("im_user_".$user_id,"password");
            if($im_user_pwd['password'] == $hash_pwd){
                $user_info = self::$redis->hGetAll("im_user_".$user_id);
            }else{
                // 使用think自带异常类抛出异常
                throw new \think\Exception('登录失败, 用户名或密码错误!', 10006);
            }
        }else{
            throw new \think\Exception('管理员不存在！', 10006);
        }
        return $user_info;
    }

    public static function register($param){
        $user = self::$redis->sisMember("im_user", $param['username']);
        if($user){
            throw new \think\Exception('用户名已存在！', 10006);
        }
//            unset($param['file']);
//            unset($param['captcha']);
        $data = [
            'avatar' => !empty($param['avatar']) ? $param['avatar'] : tomedia_qiniu("/avatar.jpg","xinshilihgb"),
            'u_src' => !empty($param['u_src']) ? $param['u_src'] : '/avatar.jpg',
            'nickname' => $param['nickname'],
            'username' => $param['username'],
            'password' => study_hash($param['password']),
            'sign' => !empty($param['sign']) ? $param['sign'] : '这个人很懒，什么都没有填写',
            'status' => "offline"   //online在线 hide隐身 offline离线
        ];
        $user_id = time().mt_rand(1,100);
        $data['user_id'] = $user_id;
        self::$redis->sAdd("im_user", $param['username']);
        self::$redis->hSet("im_user_info", $param['username'], $user_id);
//        self::$redis->hSet("im_user_info", $user_id, $param['username']);
        $res = self::$redis->hMset("im_user_".$user_id, $data);
        if (!$res) {
            throw new \think\Exception('注册失败！', 10006);
        }
        $im_friend_group_id = time().mt_rand(1,100);
        $im_friend_group_id_data = [
            "id" => $im_friend_group_id,
            "groupname" => '默认分组'
        ];
        self::$redis->hSet("im_group_".$user_id, $im_friend_group_id, json_encode($im_friend_group_id_data));







//        $data = [
//            'avatar' => !empty($param['avatar']) ? $param['avatar'] : tomedia_qiniu("/avatar.jpg","xinshilihgb"),
//            'u_src' => !empty($param['u_src']) ? $param['u_src'] : '/avatar.jpg',
//            'nickname' => $param['nickname'],
//            'username' => $param['username'],
//            'password' => study_hash($param['password']),
//            'sign' => !empty($param['sign']) ? $param['sign'] : '这个人很懒，什么都没有填写',
//            'status' => "offline"   //online在线 hide隐身 offline离线
//        ];
//        $user_id = Db::name('im_user')->insertGetId($data);
//        if (!$user_id) {
//            throw new \think\Exception('注册失败！', 10006);
//        }
//        //为用户创建默认分组
//        $im_friend_group_data = [
//            'user_id' => $user_id,
//            'groupname' => '默认分组'
//        ];
//        $im_friend_group_id = Db::name('im_friend_group')->insertGetId($im_friend_group_data);
        //将用户添加到所有人都在群
//        $im_group_member = [
//            'user_id' => $user_id,
//            'group_id' => 10001
//        ];
//        Db::name('im_group_member')->insert($im_group_member);
//        self::$redis->hMset("im_group_member".$user_id, $im_group_member);
    }
}