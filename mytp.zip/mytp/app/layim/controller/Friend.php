<?php


namespace app\layim\controller;


use think\facade\Db;

class Friend extends Controller {

    public function add_friend_group(){
        $friend_group = input("get.friend_group");
        $resId = time().mt_rand(1,100);
        $data_r = [
            'id' => $resId,
            'groupname' => $friend_group
        ];
        self::$redis->hset("im_group_".self::$im_user_info['user_id'],$resId,json_encode($data_r));


//        $data = [
//            'user_id' => self::$im_user_info['user_id'],
//            'groupname' => $friend_group
//        ];
//        $resId = Db::name('im_friend_group')->insertGetId($data);
//        if($resId){
            return $this->renderSuccess("添加成功");
//        }
//        return $this->renderError("添加失败");
    }
    public function add_friend(){
        $id = input('post.id');
        $data = self::$redis->hGet("im_system_message_".self::$im_user_info['user_id'],$id);
        $system_message = json_decode($data,true);
        $status = self::$redis->hGet("im_friend_".self::$im_user_info['user_id']."_".$system_message['uid'],"status");
        if($status == 0 && $status != false){
            return $this->renderError('已经是好友了');
        }
        self::$redis->sAdd("im_u".$system_message['uid']."_g".$system_message['group_id'],$system_message['from_id']);    //对方
        self::$redis->sAdd("im_u".$system_message['from_id']."_g".input('post.groupid'),$system_message['uid']);
        //当前自己的
        $im_friend = self::$redis->hGetAll("im_user_".$system_message['from_id']);
        $redis_data = [
            'username' => $im_friend['username'],
            'id' => $im_friend['user_id'],
            'avatar' => $im_friend['avatar'],
            'sign' => $im_friend['sign'],
        ];
        self::$redis->hSet("im_user_u".$system_message['uid']."_g".$system_message['group_id'],$system_message['from_id'],json_encode($redis_data));
        //对方的
        $im_user = self::$redis->hGetAll("im_user_".$system_message['uid']);
        $redis_data = [
            'username' => $im_user['username'],
            'id' => $im_user['user_id'],
            'avatar' => $im_user['avatar'],
            'sign' => $im_user['sign'],
        ];
        self::$redis->hSet("im_user_u".$system_message['from_id']."_g".input('post.groupid'),$system_message['uid'],json_encode($redis_data));
        unset($redis_data);
        $system_message = [
            'uid' => $system_message['uid'],
            'from_id' => $system_message['from_id'],
            'avatar' => $system_message['avatar'],
            'nickname' => $system_message['nickname'],
            'remark' => $system_message['remark'],
            'time' => $system_message['time'],
            'type' => 0,
            'group_id' => $system_message['group_id'],
            'status' => 1,
        ];
        self::$redis->hset("im_system_message_".$system_message['from_id'],$id,json_encode($system_message));
        $from_id_data_friend = [
            'status' => 0,
            'friend_group_id' => $system_message['group_id']
        ];
        self::$redis->hMset("im_friend_".$system_message['uid']."_".$system_message['from_id'],$from_id_data_friend);   ////'好友删除 0：正常 1：已删除'
        $from_id_data_friend = [
            'status' => 0,
            'friend_group_id' => input('post.groupid')
        ];
        self::$redis->hMset("im_friend_".$system_message['from_id']."_".$system_message['uid'],$from_id_data_friend);
        unset($from_id_data_friend);

        //记录用户列表的朋友。
        self::$redis->rPush("im_user_friend_u".$system_message['uid'],$system_message['from_id']);
        self::$redis->rPush("im_user_friend_u".$system_message['from_id'],$system_message['uid']);
        unset($system_message);

        return $this->renderSuccess('添加成功','',$data);
    }

    public function refuseFriend(){
        $id = input('post.id');
        $data = self::$redis->hGet("im_system_message_".self::$im_user_info['user_id'],$id);
        $system_message = json_decode($data,true);
        $im_user = self::$redis->hGetAll("im_user_".self::$im_user_info['user_id']);
        $data = [
            'uid' => $system_message['uid'],
            'from_id' => $im_user['user_id'],
            'avatar' => $im_user['avatar'],
            'nickname' => $im_user['nickname'],
            'remark' => "拒绝加你好友",
            'time' => time(),
            'type' => 1,
            'group_id' => '',
            'status' => 2,
        ];
        self::$redis->hset("im_system_message_".$system_message['uid'],$id,json_encode($data));
        self::$redis->incr("im_system_message_count:".$system_message['uid']);
        self::$redis->decr("im_system_message_count:".self::$im_user_info['user_id']);

        //将自己消息已拒绝
        $data = [
            'uid' => $system_message['uid'],
            'from_id' => $system_message['from_id'],
            'avatar' => $system_message['avatar'],
            'nickname' => urldecode($system_message['nickname']),
            'remark' => urldecode($system_message['remark']),
            'time' => $system_message['time'],
            'type' => $system_message['type'],
            'group_id' => $system_message['group_id'],
            'status' => 2,
        ];
        self::$redis->hset("im_system_message_".self::$im_user_info['user_id'],$id,json_encode($data));
        return $this->renderSuccess("已拒绝");
    }

    public function del_friend(){
        $friend_id = input('get.friend_id');
//        $group_id = input('get.group_id');
//        var_dump($group_id);
            $im_group = self::$redis->hGetAll("im_friend_".self::$im_user_info['user_id']."_".$friend_id);
            $im_friend_group = self::$redis->hGetAll("im_friend_".$friend_id."_".self::$im_user_info['user_id']);
            if($im_friend_group['status'] == 0 && $im_group['status'] == 0){

                self::$redis->del("im_friend_".self::$im_user_info['user_id']."_".$friend_id);
                self::$redis->del("im_friend_".$friend_id."_".self::$im_user_info['user_id']);

                //历史记录
                self::$redis->del("im_chat_record_u".self::$im_user_info['user_id']."_f".$friend_id);
                self::$redis->del("im_chat_record_u".$friend_id."_f".self::$im_user_info['user_id']);


                self::$redis->hdel("im_user_u".self::$im_user_info['user_id']."_g".$im_group['friend_group_id'],$friend_id);
                self::$redis->hdel("im_user_u".$friend_id."_g".$im_friend_group['friend_group_id'],self::$im_user_info['user_id']);

                self::$redis->srem("im_u".self::$im_user_info['user_id']."_g".$im_group['friend_group_id'],$friend_id);
                self::$redis->srem("im_u".$friend_id."_g".$im_friend_group['friend_group_id'],self::$im_user_info['user_id']);

            }else{
                return $this->renderError('好友删除失败');
            }
        return $this->renderSuccess('好友删除成功');
    }

    public function del_friend_group(){
        $id = input("get.id");
        $all = self::$redis->hGetAll("im_user_u".self::$im_user_info['user_id']."_g".$id);
        if(count($all) > 0){
            return $this->renderError("请先删除组内的好友!");
        }
        self::$redis->hdel("im_group_".self::$im_user_info['user_id'],$id);
        self::$redis->del("im_user_u".self::$im_user_info['user_id']."_g".$id);
        return $this->renderSuccess("成功");
    }
}