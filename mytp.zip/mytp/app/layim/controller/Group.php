<?php


namespace app\layim\controller;


use app\Request;
use think\facade\Db;
use think\facade\View;

class Group extends Controller {
    //创建组
    public function create_group(Request $request){
        if($request->isGet()){
            return View::fetch('index/create_group');
        }
        $post = input("post.");
        if(self::$redis->sisMember("im_qun_group",$post['groupname']) == false){
            $avatar = !empty($post['avatar']) ? $post['avatar'] : tomedia_qiniu("/avatar.jpg","xinshilihgb");
            $group_id = time().mt_rand(1,1000);
            $data = [
                'groupname' => $post['groupname'],
                'id'   => $group_id,
                'avatar' => $avatar,
                'u_src' => !empty($post['u_src']) ? $post['u_src'] : '/avatar.jpg',
                'status'    => 0,
                'user_id'    => self::$im_user_info['user_id']
            ];
            self::$redis->hMset("im_qun_group_g".$group_id,$data);
            self::$redis->sAdd("im_qun_group_u".self::$im_user_info['user_id'],$group_id);

            self::$redis->sAdd("im_qun_group",$post['groupname']);
            self::$redis->hset("im_qun_group_info",$post['groupname'],json_encode(["group_id"=>$group_id,"avatar"=>$avatar]));
            self::$redis->sAdd("im_qun_group_number_".$group_id,self::$im_user_info['user_id']);
            $data = [
                "type" => "group",
                "avatar"    => !empty($post['avatar']) ? $post['avatar'] : tomedia_qiniu("/avatar.jpg","xinshilihgb"),
                "groupname" => $post['groupname'],
                "id"        => $group_id
            ];
            try {
                $this->delete_index("user_group_aki");
            } catch (\Exception $e) {
                $r = "未开启elasticcsearch服务";
            }
            return renderSuccess("创建成功！",'',$data);
        }else{
            return renderError("创建失败，重复群名！");
        }
    }
    /**
     * 加入群聊
     */
    public function join_group(Request $request) {
        $id = input('post.groupid');
        $isIn = self::$redis->sisMember("im_qun_group_number_".$id,self::$im_user_info['user_id']);
        if ($isIn) {
            return $this->renderError("您已经是该群成员");
        }
        self::$redis->sAdd("im_qun_group_number_".$id,self::$im_user_info['user_id']);
        $reslut = self::$redis->hGetAll("im_qun_group_g".$id);
        self::$redis->sAdd("im_qun_group_u".self::$im_user_info['user_id'],$id);
        $data = [
            "type" => "group",
            "avatar"    => $reslut['avatar'],
            "groupname" => $reslut['groupname'],
            "id"        => $reslut['id']
        ];
        return $this->renderSuccess("加入成功",'',$data);
    }

    /**
     * 获取群成员列表
     */
    public function groupMember(Request $request){
        $group_id = input('get.id');
        $smembers = self::$redis->sMembers("im_qun_group_number_".$group_id);
        $list = [];
        foreach ($smembers as $k => $v){
            $hgelall = self::$redis->hGetAll("im_user_".$v);
            $list[$k]['username'] = $hgelall['username'];
            $list[$k]['id'] = $hgelall['user_id'];
            $list[$k]['avatar'] = $hgelall['avatar'];
            $list[$k]['sign'] = $hgelall['sign'];
        }
        $count = count($list);
        if (!$count) {
            return $this->renderError("获取群成员失败");
        }
        $user_id = self::$redis->hget("im_qun_group_g".$group_id,"user_id");
        $owner = self::$redis->hGetAll("im_user_".$user_id);
        return ['code'=>0,'msg'=>"获取群成员成功",
            'data'=> [
                'members' => $count,
                'owner'=>[              //群主
                    "username"=> $owner['username']
                    ,"id"=> $owner['user_id']
                    ,"avatar"=> $owner['avatar']
                    ,"sign"=> $owner['sign']
                ],
                'list'=>$list
            ]
        ];
    }
    /**
     * 修改群聊名称
     */
    public function editGroup(Request $request)
    {
        $group_id = trim(input('get.id'));
        $friend_group = trim(input('get.friend_group'));
        if(!$group_id || !$friend_group){
            return $this->renderError("参数错误");
        }
        $hGetAll=self::$redis->hGetAll("im_qun_group_g".$group_id,'user_id');
        if($hGetAll['user_id'] != self::$im_user_info['user_id']){
            return $this->renderError("非超级管理员不能修改名称");
        }
        if(self::$redis->sisMember("im_qun_group",$friend_group) == false){
            self::$redis->srem("im_qun_group",$hGetAll['groupname']);
            self::$redis->sAdd("im_qun_group",$friend_group);

            self::$redis->hset("im_qun_group_g".$group_id,'groupname',$friend_group);

            $im_qun_group_info = self::$redis->hGet("im_qun_group_info",$hGetAll['groupname']);
            self::$redis->hset("im_qun_group_info",$friend_group,$im_qun_group_info);
            self::$redis->hdel("im_qun_group_info",$hGetAll['groupname']);

            return $this->renderSuccess("操作成功");
        }else{
            return $this->renderError("创建失败，重复群名！");
        }
    }

    /**
     * 结算群聊
     */
    public function delGroup(Request $request) {
        $group_id = trim(input('get.group_id'));
        if(!$group_id){
            return $this->renderError("参数错误");
        }
        $hGetAll=self::$redis->hGetAll("im_qun_group_g".$group_id,'user_id');
        if($hGetAll['user_id'] != self::$im_user_info['user_id']){
            return $this->renderError("非超级管理员不能解散群聊");
        }
        if($hGetAll['user_id'] == self::$im_user_info['user_id']){
            self::$redis->del("im_qun_group_g".$group_id);
            $im_qun_group_number = self::$redis->sMembers("im_qun_group_number_".$group_id);
            foreach ($im_qun_group_number as $v){
                self::$redis->srem("im_qun_group_u".$v, $group_id);
            }
            self::$redis->del("im_qun_group_number_".$group_id);
            self::$redis->srem("im_qun_group",$hGetAll['groupname']);
            self::$redis->hdel("im_qun_group_info",$hGetAll['groupname']);
            return $this->renderSuccess("操作成功");
        }
        return $this->renderError("操作失败");
    }
}