<?php


namespace app\layim\controller;


use app\admin\controller\CacheService;
use app\api\common\JwtAuth as Api_JwtAuth;
use think\App;
use think\exception\ValidateException;
use think\Validate;
use Elasticsearch\ClientBuilder;
/**
 * 控制器基础类
 */
abstract class Controller
{
    /**
     * Request实例
     * @var \think\Request
     */
    protected $request;

    /**
     * 应用实例
     * @var \think\App
     */
    protected $app;

    /**
     * 是否批量验证
     * @var bool
     */
    protected $batchValidate = false;

    /**
     * 控制器中间件
     * @var array
     */
    protected $middleware = [];



    /**
     * 构造方法
     * @access public
     * @param  App  $app  应用对象
     */
    public function __construct(App $app)
    {
        $this->app     = $app;
        $this->request = $this->app->request;

        // 控制器初始化
        $this->initialize();

    }
    public static $redis;
    public static $im_user_info = array();
    // 初始化
    protected function initialize()
    {
        $config = array(
            'host'=> "127.0.0.1",
            'port'=> "6379",
            'auth' => "",
        );
        self::$redis = get_redis_object_do($config);
        /** @var CacheService $cacheService */
        $cacheService = app()->make(CacheService::class);
        $token = cookie("token_layim");
        //检测token是否过期
        $u_id = $this->islogin($token);
        if($u_id === false){
            return redirect('/layim/login/index')->send();
        }
        $md5Token = md5($token);
        if (!$cacheService->hasToken($md5Token) || !($cacheToken = $cacheService->getTokenBucket($md5Token))) {
            return redirect('/layim/login/index')->send();
        }
        if($u_id != $cacheToken['uid']){
            return redirect('/layim/login/index')->send();
        }
        self::$im_user_info = self::$redis->hGetAll("im_user_".$u_id);
    }

    /**
     * 验证数据
     * @access protected
     * @param  array        $data     数据
     * @param  string|array $validate 验证器名或者验证规则数组
     * @param  array        $message  提示信息
     * @param  bool         $batch    是否批量验证
     * @return array|string|true
     * @throws ValidateException
     */
    protected function validate(array $data, $validate, array $message = [], bool $batch = false)
    {
        if (is_array($validate)) {
            $v = new Validate();
            $v->rule($validate);
        } else {
            if (strpos($validate, '.')) {
                // 支持场景
                [$validate, $scene] = explode('.', $validate);
            }
            $class = false !== strpos($validate, '\\') ? $validate : $this->app->parseClass('validate', $validate);
            $v     = new $class();
            if (!empty($scene)) {
                $v->scene($scene);
            }
        }

        $v->message($message);

        // 是否批量验证
        if ($batch || $this->batchValidate) {
            $v->batch(true);
        }

        return $v->failException(true)->check($data);
    }

    protected function renderApiJson($data = []){
        return json($data);
    }


    /**
     * 返回封装后的 API 数据到客户端
     * @param int $code
     * @param string $msg
     * @param string $url
     * @param array $data
     * @return array
     */
    protected function renderJson($code = 0, $msg = '', $url = '' , $data = []){
        return json(compact('code', 'msg', 'url', 'data'));
    }
    /**
     * 返回操作成功JSON
     */
    protected function renderSuccess($msg = '', $url = '', $data = []){
        return $this->renderJson(200,$msg,$url,$data);
    }
    /**
     * 返回操作失败JSON
     * @param string $msg
     * @param string $url
     * @param array $data
     * @return array
     */
    protected function renderError($msg = '', $url = '', $data = []){
        return $this->renderJson(500,$msg,$url,$data);
    }

    protected function islogin($token = ""){
        if(!empty($token)){
            if(count(explode(".",$token)) <> 3){
                return false;
            }
            //获取JwtAuth的句柄
            $jwtAuth = Api_JwtAuth::getInstance();
            //设置token
            $jwtAuth->setToken($token);
            if($jwtAuth->validate() && $jwtAuth->verify()){
                return $jwtAuth->decdoe()->getClaim("uid");
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    private $client;
    public function connect_es(){
        $params = array(
            '127.0.0.1:9200'
        );
        $this->client = ClientBuilder::create()->setHosts($params)->build();
    }

    public function fenci(){
        $this->connect_es();
        $params = [
            'body' => [
                //中文分词
                 'text' => "123a",
                 'analyzer'=>'ik_max_word', //ik_max_word 最细粒度拆分 ik_smart最粗粒度拆分
                //拼音分词
//                "text" => "张记麻辣香锅",
//                "analyzer" => "pinyin"
            ]
        ];
        return $res =  $this->client->indices()->analyze($params);
    }
    //创建索引
    function createIndex($index_name = 'aki'){
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'body' => [
                'settings' => [
                    'number_of_shards' => 2,
                    'number_of_replicas' => 0
                ],
            ]
        ];
        return $this->client->indices()->create($params);
    }
    //是否存在索引
    public function existsIndex($index_name = 'aki'){
        $this->connect_es();
        $params = ['index' => $index_name];
        if($this->client->indices()->exists($params)){
            return true;
        }
        return false;
    }
    // 删除索引
    public function delete_index($index_name = 'aki') {
        $this->connect_es();
        $params = ['index' => $index_name];
        $response = $this->client->indices()->delete($params);
        return $response;
    }
    // 查看映射
    public function get_mapping($type_name = 'users',$index_name = 'aki') {
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'include_type_name' => true,
            'type' => $type_name
        ];
        try {
            $response = $this->client->indices()->getMapping($params);
        } catch (\Exception $e) {
            return false;
        }
        return $response;

    }
    public function createMappings($type_name = 'users',$index_name = 'aki', $properties= array()) {
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'include_type_name' => true,
            'type' => $type_name,
            'body' => [
                $type_name => [
                    '_source' => [
                        'enabled' => true
                    ],
                    'properties' => $properties
                ]
            ]
        ];
        try {
            $response = $this->client->indices()->putMapping($params);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
        return $response;
    }
    // 添加文档
    public function add_doc($id,$doc,$type_name = 'users',$index_name = 'aki') {
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'type' => $type_name,
            'id' => $id,
            'body' => $doc
        ];
        $response = $this->client->index($params);
        return $response;
    }
    // 判断文档存在
    public function exists_doc($id = 1,$type_name = 'users',$index_name = 'aki') {
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'type' => $type_name,
            'id' => $id
        ];
        $response = $this->client->exists($params);
        return $response;
    }
    // 查询文档 (分页，排序，权重，过滤)
    public function search_doc($keywords = "运维",$index_name = "aki",$type_name = "users",$from = 0,$size = 2,$sort_doc = array(),$query = array()) {
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'type' => $type_name,
            'body' => [
                'query' => [
                    'bool' => $query
                ],
                'track_total_hits' => true, //返回所有满足记录数
                'sort' => $sort_doc,        //Sort 排序 $sort排序字段,
                //Size 和 from 分页
                'from' => $from,
                'size' => $size
            ]
        ];
        $results = $this->client->search($params);
        return $results;
    }
    public function search_doc_num($keywords = "运维",$index_name = "aki",$type_name = "users",$from = 0,$size = 2,$sort_doc = array(),$query = array()) {
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'type' => $type_name,
            'body' => [
                'query' => [
                    'bool' => $query
                ],
                'track_total_hits' => true, //返回所有满足记录数
                'sort' => $sort_doc,        //Sort 排序 $sort排序字段,
            ]
        ];
        $results = $this->client->search($params);
        return $results;
    }
    // 获取文档
    public function get_doc($id = 1,$type_name = 'users',$index_name = 'aki') {
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'type' => $type_name,
            'id' => $id
        ];
        try {
            $response = $this->client->get($params);
        } catch (\Exception $e) {
            // echo $e->getMessage();
            return false;
        }
        return $response;
    }
    // 更新文档
    public function update_doc($id = 1,$doc,$type_name = 'users',$index_name = 'aki') {
        $this->connect_es();
        // 可以灵活添加新字段,最好不要乱添加
        // unset($doc['id']);
        $params = [
            'index' => $index_name,
            'type' => $type_name,
            'id' => $id,
            'body' => [
                'doc' => $doc
            ]
        ];
        try {
            $response = $this->client->update($params);
        } catch (\Exception $e) {
            // echo $e->getMessage();
            return false;
        }
        return $response;
    }
    // 删除文档
    public function delete_doc($id = 1,$type_name = 'users',$index_name = 'aki') {
        $this->connect_es();
        $params = [
            'index' => $index_name,
            'type' => $type_name,
            'id' => $id
        ];
        try {
            $response = $this->client->delete($params);
        } catch (\Exception $e) {
            // echo $e->getMessage();
            return false;
        }
        return $response;
    }
}