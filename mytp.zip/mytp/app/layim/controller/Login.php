<?php


namespace app\layim\controller;


use app\layim\validate\ImUserValidate;
use app\layim\model\ImUserModel;
use app\Request;
use think\facade\Db;
use think\exception\ValidateException;
use think\facade\View;

class Login
{
    public function index(){
        return View::fetch('/login');

    }
    public function login(Request $request){
        if($request->isPost()){
            $params = input("post.");
            $model = new ImUserModel();
            if(is_array($arr = $model::login($params, "im_user"))){
                return $arr;
            };
            return renderSuccess('登录成功',"/layim/index/index.html");
        }
    }
    public function register(Request $request){
        if ($request->isPost()) {
            $param = input('param.');
            try{
                if(!captcha_check($param['captcha'])){
                    return renderError("验证码错误");
                };
            }
            catch (\Exception $e){
                // 这是进行异常捕获
                return renderError($e->getMessage());
            }
            //验证规则
            if(is_numeric($param['username'])){
                return renderError("用户名不能全是数字");
            }
            try {
                validate(ImUserValidate::class)->scene('get')
                    ->check([
                        'username' => $param['username'],
                        'password' => $param['password'],
                        'nickname' => $param['nickname']
                    ]);
            }
            catch (ValidateException $e) {
                // 验证失败 输出错误信息
                return renderError($e->getError());
            }

//            $user = Db::name('im_user')->where('username', $param['username'])->findOrEmpty();
//            if(!$user){
//                return $this->renderError("用户名已存在");
//            }
            $model = new ImUserModel();
            if(is_array($arr = $model::register($param))){
                return $arr;
            }
            return renderSuccess('注册成功');
        } else {
            $code_hash = uniqid().uniqid();
            return View::fetch('/register',['code_hash' => $code_hash]);
        }
    }
}