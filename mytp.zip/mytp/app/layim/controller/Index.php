<?php


namespace app\layim\controller;


use app\admin\controller\CacheService;
use app\layim\model\ImUserModel;
use app\Request;
use think\Exception;
use think\facade\Db;
use think\facade\View;

class Index extends Controller
{
    public function index(){
        try {
            View::assign("avatar", self::$im_user_info['avatar']);
            View::assign("username", self::$im_user_info['username']);
            View::assign("sessionid", self::$im_user_info['user_id']);
            return View::fetch('index');
        }catch(Exception $exception){
            writelog(007, 007, 'layim【' . $exception->getMessage() . '】', 1);
            return redirect('/layim/login/index')->send();
        }
    }
    public function userinfo(){
        $groups = Db::name('im_group_member')
            ->alias("gm")
            ->leftJoin('im_group g','g.id = gm.group_id')
            ->field('g.id,g.groupname,g.avatar')
            ->where('g.status',0)
            ->where('gm.user_id', self::$im_user_info['user_id'])
            ->select();

        $groups = self::$redis->sMembers("im_qun_group_u".self::$im_user_info['user_id']);
        $array_groups = [];
        $i=0;
        foreach ($groups as $value){
            $array_groups[$i] = self::$redis->hGetAll("im_qun_group_g".$value);
            $i++;
        }
        //redis
        $friend_group_r = self::$redis->hGetAll("im_group_".self::$im_user_info['user_id']);
        $array = [];
        $i = 0;
        foreach ($friend_group_r as $k => $v){
            $array[$i] = json_decode($v,true);
            $array[$i]['list'] = [];
            foreach (self::$redis->sMembers("im_u".self::$im_user_info['user_id']."_g".$k) as $va){
                $s = json_decode(self::$redis->hGet("im_user_u".self::$im_user_info['user_id']."_g".$k,$va),true);
                $s['status'] = self::$redis->hGet("im_user_status_".$s['id'],'status');
                $array[$i]['list'][] = $s;
            }
            $i++;
        }
        $data = [
            'mine'      => [
                'username'  => self::$im_user_info['nickname'],//昵称
                'id'        => self::$im_user_info['user_id'],     //pid
                'status'    => self::$im_user_info['status'], //在线状态 online在线 hide：隐身
                'sign'      => self::$im_user_info['sign'],   //签名
                'avatar'    => self::$im_user_info['avatar']  //头像
            ],
            "friend"    => $array,
            "group"     => $array_groups
        ];
        return $this->renderJson(0,'获取数据成功','',$data);
    }

    public function find(){
        $type = input('get.type');
        $wd = trim(input('get.wd'));
        $user_list = [];
        $group_list = [];
        $page = trim(input('get.page'));
        if ( isset($page) && $page >1) {
            $pageVal = $page - 1;
        }else {
            $pageVal = 0;
            $page = 1;
        }
        $limit = 1;
        $num = 0;
        switch ($type) {
            case "user" :
                $is_elastic = 1;
                if($is_elastic){
                    $isidnex = true;
                    $index_name = "user_aki";
                    $type_index_name = "user_type_aki";
                    try {
//                        $this->delete_index($index_name);
                        $isidnex = $this->existsIndex($index_name);
                    } catch (\Exception $e) {
                         return "未开启elasticcsearch服务";
                    }
//                    dump($this->fenci()); //测试IK分词
                    if($isidnex == false){
                        $this->createIndex($index_name);		//创建索引
                    }
                    $is_get_mapping = $this->get_mapping($type_index_name,$index_name);
                    if($is_get_mapping == false){
                        //映射索引(相当于mysql表格新增字段)
                        $array = [
                            'user_id' => [
                                'type' => 'text'
                            ],
                            'nickname' => [
                                'type' => 'text',
//                                'analyzer' => ['pinyin','ik_max_word']
                                'analyzer' => 'pinyin'
//                                'analyzer' => 'ik_max_word'
                            ],
                            'avatar' => [
                                'type' => 'text' // 字符串型
                            ]
                        ];
                        $this->createMappings($type_index_name,$index_name,$array);
                    }

                    $all = self::$redis->hGetAll("im_user_info");
                    $es_store_v = [];
                    foreach ($all as $k => $v){
                        $id = 'find_'.$v;
                        $user = self::$redis->hGetAll("im_user_".$v);
                        $es_store_v['user_id'] = $user['user_id'];
                        $es_store_v['nickname'] = $user['nickname'];
                        $es_store_v['avatar'] = $user['avatar'];
                        //id我取的数据库的主键id,必须唯一
                        if($this->exists_doc($id,$type_index_name,$index_name) == false){
                            $this->delete_doc($id,$type_index_name,$index_name);
                            $this->add_doc($id,$es_store_v,$type_index_name,$index_name); //3.添加文档
                        }else{
//                            $this->delete_doc($id,$type_index_name,$index_name);
//                            $this->add_doc($id,$es_store_v,$type_index_name,$index_name);
//                            $this->update_doc($id,$es_store_v,$type_index_name,$index_name);
                        }
                        //查找文档
//                        $r2 = $this->get_doc($id,$type_index_name,$index_name);
//                        dump($r2);
                    }
                    $sort_doc = [];
                    //模糊查询,bool查询里must和should同时使用需要设置minimum_should_match为1
                    $query = [
                        'should' => [
                            [
                                'match' => [
                                    'user_id' => [
                                        'query' => $wd,
                                        'boost' => 1, // 权重大
                                    ]
                                ]
                            ],
                            [
                                'match' => [
                                    'nickname' => [
                                        'query' => $wd,
                                        'boost' => 3,
                                    ]
                                ]
                            ]
                        ],
                        'minimum_should_match' =>1,
                    ];

                    $r = $this->search_doc($wd,$index_name,$type_index_name,$from = $pageVal,$size = $limit,$sort_doc,$query); //4.搜索结果
                    $r_num = $this->search_doc_num($wd,$index_name,$type_index_name,$from = 0,$size = 0,$sort_doc,$query); //4.搜索结果
                    $num = $r_num['hits']['total'];
                    $data_new = [];
                    foreach ($r['hits']['hits'] as $key =>$value){
                        $data_new[$key] = $value['_source'];
                    }
                    $user_list = $data_new;
                }
                break;
            case "group" :
                $is_elastic = 1;
                if($is_elastic){
                    $isidnex = true;
                    $index_name = "user_group_aki";
                    $type_index_name = "user_group_type_aki";
                    try {
                        $isidnex = $this->existsIndex($index_name);
                    } catch (\Exception $e) {
                        return "未开启elasticcsearch服务";
                    }
                    if($isidnex == false){
                        $this->createIndex($index_name);		//创建索引
                    }else{
//                        $this->delete_index($index_name);
                    }
                    $is_get_mapping = $this->get_mapping($type_index_name,$index_name);
                    if($is_get_mapping == false){
                        //映射索引(相当于mysql表格新增字段)
                        $array = [
                            'group_id' => [
                                'type' => 'text'
                            ],
                            'groupname' => [
                                'type' => 'text',
//                                'analyzer' => ['pinyin','ik_max_word']
                                'analyzer' => 'pinyin'
//                                'analyzer' => 'ik_max_word'
                            ],
                            'avatar' => [
                                'type' => 'text' // 字符串型
                            ]
                        ];
                        $this->createMappings($type_index_name,$index_name,$array);
                    }

                    $alls = self::$redis->sMembers("im_qun_group");
                    $es_store_v = [];
                    foreach ($alls as $k => $v){
                        $id = 'find_'.$v;
                        $group_info = self::$redis->hget("im_qun_group_info",$v);
                        $group_info = json_decode($group_info,true);
                        $es_store_v['group_id'] = $group_info['group_id'];
                        $es_store_v['groupname'] = $v;
                        $es_store_v['avatar'] = $group_info['avatar'];
                        //id我取的数据库的主键id,必须唯一
                        if($this->exists_doc($id,$type_index_name,$index_name) == false){
                            $this->add_doc($id,$es_store_v,$type_index_name,$index_name); //3.添加文档
                        }
                    }
                    $sort_doc = [];
                    //模糊查询,bool查询里must和should同时使用需要设置minimum_should_match为1
                    $query = [
                        'should' => [
                            [
                                'match' => [
                                    'group_id' => [
                                        'query' => $wd,
                                        'boost' => 1, // 权重大
                                    ]
                                ]
                            ],
                            [
                                'match' => [
                                    'groupname' => [
                                        'query' => $wd,
                                        'boost' => 3,
                                    ]
                                ]
                            ]
                        ],
                        'minimum_should_match' =>1,
                    ];
                    $r = $this->search_doc($wd,$index_name,$type_index_name,$from = $pageVal,$size = $limit,$sort_doc,$query); //4.搜索结果
                    $r_num = $this->search_doc_num($wd,$index_name,$type_index_name,$from = 0,$size = 0,$sort_doc,$query); //4.搜索结果
                    $num = $r_num['hits']['total'];
                    $data_new = [];
                    foreach ($r['hits']['hits'] as $key =>$value){
                        $data_new[$key] = $value['_source'];
                    }
                    $group_list = $data_new;
                }
                break;
            default :
                break;
        }
        View::assign("pageNum",$num);
        View::assign("pageVal",$page);
        View::assign("limit",$limit);
        View::assign("user_list",$user_list);
        View::assign("group_list",$group_list);
        View::assign("type",$type);
        View::assign("wd",$wd);
        return View::fetch();
    }
    public function message_box(){
        $list = array();
        $data = self::$redis->hGetAll("im_system_message_".self::$im_user_info['user_id']);
        foreach ($data as $k => $val){
            $arr_data = json_decode($val,true);
            $arr_data['id'] = $k;
            $arr_data['time_temp'] = $arr_data['time'];
            $arr_data['time'] = time_tranx($arr_data['time']);
            $arr_data['nickname'] = urldecode($arr_data['nickname']);
            $list[] = $arr_data;
        }
        $cmf_arr = array_column($list, 'time_temp');
        array_multisort($cmf_arr, SORT_DESC, $list);
        self::$redis->del("im_system_message_count:".self::$im_user_info['user_id']);
        View::assign("list",$list);
        return View::fetch();
    }

    /**
     * 聊天日志页面
     */
    public function chat_log()
    {
        $id = input('get.id');
        $type = input('get.type');
        return View::fetch('chat_log',['id' => $id,'type' => $type]);
    }
    /**
     * 聊天日志数据
     */
    public function chat_record_data()
    {
        $id = input('get.id');
        $type = input('get.type');
        $page = input('get.page');
        $list_data = [];
        if($type == 'group'){
            $group_lLen = self::$redis->lLen("im_chat_record_g".$id);
            $list = self::$redis->lRange("im_chat_record_g".$id,0,-1);
            foreach ($list as $k => $v){
                $list[$k] = json_decode($list[$k],true);
                $list[$k]['timestamp'] = $list[$k]['timestamp'] * 1000;
                $list[$k]['content'] = urldecode($list[$k]['content']);
            }
            $list_data['total'] = $group_lLen;
            $list_data['per_page'] = 10;
            $list_data['current_page'] = $page;
            $list_data['last_page'] = 0;
            $list_data['data'] = $list;
        } else {
//            $lLen = self::$redis->lLen("im_chat_record_u".self::$im_user_info['user_id']."_f".$id);
            $res =self::$redis->lRange("im_chat_record_u".self::$im_user_info['user_id']."_f".$id,0,-1);
            $friend_lLen = self::$redis->lLen("im_chat_record_u".$id."_f".self::$im_user_info['user_id']);
            $friend_res =self::$redis->lRange("im_chat_record_u".$id."_f".self::$im_user_info['user_id'],0,$friend_lLen);
            $list = $res;
            $friend_list = $friend_res;
            foreach ($list as $k=>$v){
                $list[$k] = json_decode($list[$k],true);
                $list[$k]['timestamp'] = $list[$k]['timestamp'] * 1000;
                $list[$k]['content'] = urldecode($list[$k]['content']);
            }
            foreach ($friend_list as $kd => $v){
                $friend_list[$kd] = json_decode($friend_list[$kd],true);
                $friend_list[$kd]['timestamp'] = $friend_list[$kd]['timestamp'] * 1000;
                $friend_list[$kd]['content'] = urldecode($friend_list[$kd]['content']);
            }
            $list_data['total'] = $friend_lLen;
            $list_data['per_page'] = 10;
            $list_data['current_page'] = $page;
            $list_data['last_page'] = 0;
            $list_data['data'] = array_merge($list,$friend_list);

            $cmf_arr = array_column($list_data['data'], 'timestamp');
            array_multisort($cmf_arr, SORT_ASC, $list_data['data']);
        }

        return $this->renderSuccess('','',$list_data);

    }
    /**
     * 修改用户签名
     */
    public function update_sign(){
        $sign = input('post.sign');
        $res = Db::name('im_user')->where('id', self::$im_user_info['user_id'])->update(['sign' => $sign]);
        $res1 = self::$redis->hset('im_user_'.self::$im_user_info['username'],'sign',$sign);
        if (!$res && $res1) {
            return $this->renderError('签名修改失败');
        }
        return $this->renderSuccess('签名修改成功');
    }
    public function loginout(){
        $token = cookie("token_layim");
        $key = md5($token);
        CacheService::redisHandler()->delete($key);
        cookie('token_layim', null);
        return redirect('/layim');
    }
}