<?php

namespace app\layim\validate;
use think\Validate;

class ImUserValidate extends Validate
{
    protected $rule = [
        'username' => 'require|max:100',
        'password' => 'require',
        'nickname' => 'require|max:255'
    ];
    protected $message  =   [
        'username.require'=>'请填写用户名',
        'username.max'=>'用户名超长，请不要输入太长',
        'password.require'=>'请填写密码',
        'password.between'=>'请输入1-20位密码',
        'nickname.require'=>'请填写昵称',
    ];

    protected $scene = [
        'get' => ['username', 'password', 'nickname'],
        'update' => ['username', 'password','nickname'],
    ];
}