<?php
namespace app\index\route;
use think\facade\Route;
Route::get('/',function (){
    return redirect('/layim/login/index.html');
});
Route::get('login/index',"Login/index");
Route::post('login/login',"Login/login");
Route::get('login/register',"Login/register");
Route::post('login/register',"Login/register");

Route::get('Login/captcha/[:config]','\\think\\captcha\\CaptchaController@index');

Route::get('index/index',"Index/index");
Route::get('index/loginout',"Index/loginout");
Route::get('index/userinfo',"Index/userinfo");
Route::get('index/find',"Index/find");
Route::get('index/message_box',"Index/message_box");

Route::get('index/create_group',"Group/create_group");
Route::post('index/join_group',"Group/join_group");
Route::post('index/create_group',"Group/create_group");
Route::get('index/group_members',"Group/groupMember");
Route::get('index/edit_group','Group/editGroup');        //修改群聊名称
Route::get('index/del_group','Group/delGroup');          //解散群聊名称


Route::get('index/add_friend_group',"Friend/add_friend_group");
Route::post('index/add_friend',"Friend/add_friend");
Route::post('index/refuse_friend',"Friend/refuseFriend");
Route::get('index/del_friend',"Friend/del_friend");
Route::get('index/del_friend_group',"Friend/del_friend_group");

Route::get('index/chat_log',"Index/chat_log");
Route::get('index/chat_record_data',"Index/chat_record_data");
Route::post('index/update_sign',"Index/update_sign");

