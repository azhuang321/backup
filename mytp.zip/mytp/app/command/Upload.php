<?php


namespace app\command;


use app\Request;

class Upload
{
    public static function upload(Request $request){

        $file = $request->file('file');
        $path = input('path') ? input('path') : '';
        $path = 'uploads/'.$path.'/'.date('Ymd').'/';
        if (!$file) {
            return renderError('请选择上传的文件');
        }
        if (!$file->isValid()) {
            return renderError('文件验证失败！');
        }
        $upload = new \Dj\Upload();
        $filelist = $upload->save($path);
        if(is_array($filelist)){        # 返回数组，文件就上传成功了
            //七牛
            $result = save_image_to_qiniu($filelist['savepath'],$filelist['uri']);
            if($result['code'] == 0){
                $data = array();
                $data['src'] = tomedia_qiniu($filelist['uri'],"xinshilihgb");
                $data['u_src'] = $filelist['uri'];
                return renderSuccess("success","",$data);
            }else{
                return renderError($result['msg']);
            }
        }else{
            # 如果返回负整数(int)就是发生错误了
            $error_msg = [-1=>'上传失败',-2=>'文件存储路径不合法',-3=>'上传非法格式文件',-4=>'文件大小不合符规定',-5=>'token验证错误'];
            return renderError($error_msg[$filelist]);
        }
    }
}