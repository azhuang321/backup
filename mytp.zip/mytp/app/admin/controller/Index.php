<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2021/3/29 0029
 * Time: 17:26
 */

namespace app\admin\controller;

use think\facade\View;

class Index extends Controller{
    public function index(){
        return View::fetch("layouts/layout");
    }
    public function indexPage(){
        return View::fetch('indexPage');
    }

    /**
     * 清除缓存
     */
    public function clear() {
//        if (delete_dir_file(CACHE_PATH) && delete_dir_file(TEMP_PATH)) {
//            return $this->renderSuccess('清除缓存成功');
//        } else {
//            return $this->renderError('清除缓存失败');
//        }
    }

    public function login(){
        return "admin/login";
    }

    public function redis1(){
        $redis = get_redis_object_do();
        dump($redis);
    }

}