<?php


namespace app\admin\controller;


use app\admin\model\Admin;
use app\admin\validate\AdminValidate;
use think\facade\Session;
use think\facade\View;
use think\facade\Config;
use think\facade\Cache as CacheStatic;

class Login
{
    public function index(){
        // 模板输出
        return View::fetch('/login');
    }


    public function doLogin(){
        $data = input('post.');
        $model = new Admin();
        if(is_array($arr = $model->login($data, "admin"))){
            return $arr;
        };
//        $url = url('index/index');
        return ['code'=>1,'msg'=>'登录成功','url'=> "/admin/index/index.html"];
    }
    //退出登录
    public function loginOut(){
        $token = cookie("token_hgb");
        $key = md5($token);
        CacheService::redisHandler()->delete($key);
        return redirect('index');
    }

    /**
     * geetest生成验证码
     */

    public function geetest_show_verify(){

        $geetest_id=Config::get('config.GEETEST_ID');
        $geetest_key=Config::get('config.GEETEST_KEY');
        $geetest= new \org\Xb\Geetest($geetest_id,$geetest_key);
        $user_id = "test";
        $status = $geetest->pre_process($user_id);
        Session::set('geetest',[
            'gtserver'=>$status,
            'user_id'=>$user_id
        ]);
        echo $geetest->get_response_str();
    }


}