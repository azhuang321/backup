<?php
declare (strict_types = 1);
namespace app\admin\controller;

use app\admin\model\Admin;
use app\admin\model\Node;
use app\admin\model\UserType;
use com\Auth;
use think\Exception;
use think\facade\Db;
use app\api\common\JwtAuth as Api_JwtAuth;
use think\App;
use think\exception\ValidateException;
use think\facade\View;
use think\Validate;

/**
 * 控制器基础类
 */
abstract class Controller
{
    /**
     * Request实例
     * @var \think\Request
     */
    protected $request;
    /**
     * 应用实例
     * @var \think\App
     */
    protected $app;
    /**
     * 是否批量验证
     * @var bool
     */
    protected $batchValidate = false;
    /**
     * 控制器中间件
     * @var array
     */
    protected $middleware = [];
    /**
     * 构造方法
     * @access public
     * @param  App  $app  应用对象
     */
    public function __construct(App $app){
        $this->app     = $app;
        $this->request = $this->app->request;
        // 控制器初始化
        $this->initialize();

    }

    // 初始化
    protected function initialize(){
        /** @var CacheService $cacheService */
        $cacheService = app()->make(CacheService::class);
        $token = cookie("token_admin");
        //检测token是否过期
        $u_id = $this->islogin($token);
        if($u_id === false){
            return redirect('/admin/login/index')->send();
        }
        $md5Token = md5($token);
        if (!$cacheService->hasToken($md5Token) || !($cacheToken = $cacheService->getTokenBucket($md5Token))) {
            return redirect('/admin/login/index')->send();
        }
        if($u_id != $cacheToken['uid']){
            return redirect('/admin/login/index')->send();
        }

        $auth = new Auth();
//        app('http')->getName();
//        \think\facade\App::instance()->http->getName();

        $module     = strtolower($this->app->http->getName());
        $controller = strtolower(request()->controller());
        $action     = strtolower(request()->action());
        $url        = $module."/".$controller."/".$action;
        //跳过检测以及主页权限
        try{
            if($u_id != 1){
                if(!in_array($url, ['admin/index/index','admin/index/indexpage'])){
                    if(!$auth->check($url,$u_id)){
                        throw new Exception('抱歉，您没有操作权限');
                    }
                }
            }
        }catch (\Exception $e){
            echo json_encode(["code"=>-1,"msg"=>$e->getMessage()]);
            die();
        }
        $node = new Node();
        $usertype = new UserType();
        $admin_model = new Admin();
        $admin_info = $admin_model->where("id",$u_id)->find();
        if(!$admin_info){
            return redirect('/admin/login/index')->send();
        }
        if(!$admin_info['status']){
            return redirect('/admin/login/index')->send();
        }
        $this->store = [
            'user' => [
                'uid' => $u_id,               //用户ID
                'user_name' => $admin_info['user_name'],  //用户名
                'rolename' =>$admin_info['title'],        //角色名
            ],
            'ip' => request()->ip(),
        ];
        $groupid = Db::name("admin")->where("id",$u_id)->value("groupid");
        $info = $usertype->getRoleInfo($groupid);   //获取角色信息
        empty($info['rules']) ? $info['rules'] = '' : '';
        View::assign([
            'menu' => $node->getMenu($info['rules'], $u_id),
        ]);
    }

    /**
     * 验证数据
     * @access protected
     * @param  array        $data     数据
     * @param  string|array $validate 验证器名或者验证规则数组
     * @param  array        $message  提示信息
     * @param  bool         $batch    是否批量验证
     * @return array|string|true
     * @throws ValidateException
     */
    protected function validate(array $data, $validate, array $message = [], bool $batch = false)
    {
        if (is_array($validate)) {
            $v = new Validate();
            $v->rule($validate);
        } else {
            if (strpos($validate, '.')) {
                // 支持场景
                [$validate, $scene] = explode('.', $validate);
            }
            $class = false !== strpos($validate, '\\') ? $validate : $this->app->parseClass('validate', $validate);
            $v     = new $class();
            if (!empty($scene)) {
                $v->scene($scene);
            }
        }

        $v->message($message);

        // 是否批量验证
        if ($batch || $this->batchValidate) {
            $v->batch(true);
        }

        return $v->failException(true)->check($data);
    }

    /* @var array $store 登录信息 */
    protected $store;
    /**
     * 返回封装后的 API 数据到客户端
     * @param int $code
     * @param string $msg
     * @param string $url
     * @param array $data
     * @return array
     */
    protected function renderJson($code = 1, $msg = '', $url = '' , $data = []){
        return compact('code', 'msg', 'url', 'data');
    }
    /**
     * 返回操作成功JSON
     */
    protected function renderSuccess($msg = '', $url = '', $data = []){
        return $this->renderJson(1,$msg,$url,$data);
    }
    /**
     * 返回操作失败JSON
     * @param string $msg
     * @param string $url
     * @param array $data
     * @return array
     */
    protected function renderError($msg = '', $url = '', $data = []){
        return $this->renderJson(0,$msg,$url,$data);
    }

    protected function islogin($token = ""){
        if(!empty($token)){
            if(count(explode(".",$token)) <> 3){
                return false;
            }
            //获取JwtAuth的句柄
            $jwtAuth = Api_JwtAuth::getInstance();
            //设置token
            $jwtAuth->setToken($token);
            if($jwtAuth->validate() && $jwtAuth->verify()){
                return $jwtAuth->decdoe()->getClaim("uid");
            }else{
                return false;
            }
        }else{
            return false;
        }

//        if(empty($this->store)){
//            $this->redirect('admin/login/index');
//            return false;
//        }
//        return true;

    }
}