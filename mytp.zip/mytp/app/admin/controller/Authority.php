<?php


namespace app\admin\controller;


use app\admin\model\Admin as UserModel;
use app\admin\model\Admin;
use app\admin\model\Node;
use app\admin\model\UserType;
use app\admin\validate\UserValidate;
use think\facade\Db;
use think\facade\View;

class Authority extends Controller
{
    public function index(){
        $roles = UserType::where("id",">",1)->order('id desc')->select();  //角色
        $users = UserModel::where('id', '<>', 1)->order('id desc')->paginate(15);//管理员
        return View('index',[
            'roles' => $roles,
            'users' => $users,
        ]);
    }

    //管理员添加
    public function userAdd(){
        if (request()->isAjax()) {
            $param = input('post.');
            $param['password'] = study_hash($param['password']);
            $validate = new UserValidate();
            $res = $validate->check($param);
            if (false === $res) {
                return ["code" => 0, "msg"=> $validate->getError()];
            }
            $flag = Admin::create($param);
            writelog($this->store['user']['uid'], $this->store['user']['user_name'], '用户【'.$this->store['user']['user_name'].'】添加了'.$param['user_name'].'管理员', 1);
            $accdata = array(
                'uid' => $flag->id,
                'group_id' => $param['groupid'],
            );
            Db::name('auth_group_access')->insert($accdata);
            return $this->renderSuccess('添加管理员成功');
        }
        $role = new UserType();
        return View('', [
            'role' => $role->getRole(),
        ]);
       return $this->fetch('user_add');
    }
    /**
     * [user_state 修改状态]
     */
    public function user_state(){
        $id = input('param.id');
        $admin = new Admin();
        $res = $admin->update_status($id);
        if($res['code'] == 1){
            return $this->renderSuccess($res['msg']);
        }
        return $this->renderError($res['msg']);
    }
    /**
     * 管理员编辑
     */
    public function user_edit(){
        $id = input('id');
        $user = Admin::find($id);
        $role = new UserType();
        if(request()->isAjax()){
            $param = input('post.');
            Admin::update($param,['id' => $param['id']]);
            return $this->renderSuccess('更改成功', (string)url('authority/index'));
        }
        return View('',[
            'user' => $user,
            'role' => $role->getRole(),
        ]);
    }
    /**
     * 管理员删除
     */
    public function userDel(){
        $id = input('post.id');
        $res = Admin::destroy($id); //return int 1
        if($res == 1){
            return $this->renderSuccess('删除成功', (string)url('authority/index'));
        }
        return $this->renderError('删除失败');
    }

    //角色添加
    public function roleAdd(){
        if(request()->isPost()){
            $param = input('post.');
            $role = new UserType();
            $flag = $role->insertRole($param);
            if($flag['code'] == 1){
                return $this->renderSuccess($flag['msg'],(string)url('authority/index'),$flag['data']);
            }
            return $this->renderError($flag['msg']);
        }
        return View('');
    }
    //角色编辑
    public function roleEdit(){
        $id = input('id');
        $role = UserType::find($id);
        View::assign('role',$role);
        if(request()->isPost()){
            $data = input('post.');
            $roles = new UserType();
            $flags = $roles->editRole($data);
            if($flags['code'] == 1){
                return $this->renderSuccess($flags['msg'],(string)url('authority/index'),$flags['data']);
            }
            return $this->renderError($flags['msg']);
        }
        return View('');
    }
    //删除角色
    public function roleDel()
    {
        $id = input('param.id');
        $flag = UserType::destroy($id);
        if ($flag) {
            return $this->renderSuccess('删除成功', (string)url('authority/index'));
        } else {
            return $this->renderError('删除失败');
        }
    }
    //权限编辑
    public function giveAccess(){
        $param = input('param.');
        $node = new Node();
        //获取现在的权限
        if('get' == $param['type']){
            $nodeStr = $node->getNodeInfo($param['id']);
            return $this->renderSuccess('success','',$nodeStr);
        }

        //分配新权限
        if ('give' == $param['type']) {
            $doparam = [
                'id' => $param['id'],
                'rules' => $param['rule']
            ];
            $user = new UserType();
            $flag = $user->editAccess($doparam);
            if($flag['code'] == 1){
                return $this->renderSuccess($flag['msg'],'',$flag['data']);
            }else{
                return $this->renderError($flag['msg']);
            }
        }
    }
}