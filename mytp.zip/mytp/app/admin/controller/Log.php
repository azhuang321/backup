<?php
namespace app\admin\controller;

use app\admin\model\LogModel;
use think\facade\Db;
use com\IpLocation;
use think\facade\View;

class Log extends Controller{
	public function operate_log(){
		$key = input('search');
		$map = [];
        if($key && $key!==""){
            $map['admin_id'] =  $key;
        }
		$arr=Db::name("admin")->column("id,user_name"); //获取用户列表
        $count = Db::name('log')->where($map)->count();//计算总页面
//        $lists = Db::name('log')->where($map)->order('add_time desc')->page(1,$count)->select();
        $lists = Db::name('log')->where($map)->order('add_time desc')->paginate(30);
        $Ip = new IpLocation('UTFWry.dat'); // 实例化类 参数表示IP地址库文件
        $list_copy = $lists->items();
        foreach($lists as $k => $v){
            $list_copy[$k]["ipaddr"] = $Ip->getlocation($v['ip']);
        }
        View::assign('count', $count);
        View::assign("search_user",$arr);
        View::assign('val', $key);
        View::assign('lists', $list_copy);
        View::assign('lists_render', $lists);
        return View::fetch();
	}
	/**
     * [del_log 删除日志]
     */
    public function del_log()
    {
        $id = input('post.id');
        $log = new LogModel();
        $flag = $log->delLog($id);
        return $this->renderSuccess($flag['msg'],(string)url('log/operate_log'));
    }
}