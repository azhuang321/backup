<?php


namespace app\admin\controller;

use app\admin\model\Menu as MenuModel;
use think\App;
use think\facade\View;

class Menu extends Controller
{
    public function index(){
        $nav = new \org\leftnav();
        $menu = new MenuModel;
        $admin_rule = $menu->getAllMenu();
        $arr = $nav::rule($admin_rule);
        return View('',[
            'admin_rule' => $arr
        ]);
    }

    /**
     * 添加菜单
     */
    public function add_rule(){
        if(request()->isAjax()){
            $param = input('post.');
            $menu = new MenuModel();
            $flag = $menu->insertMenu($param);
            if($flag['code'] == 1){
                writelog($this->store['user']['uid'], $this->store['user']['user_name'], '用户【'.$this->store['user']['user_name'].'】添加了'.$param['name'].'菜单', 1);
                return $this->renderSuccess($flag['msg'],(string)url('menu/index'),$flag['data']);
            }
            return $this->renderError($flag['msg'],(string)url('menu/index'),$flag['data']);
        }
    }
    /**
     * [edit_rule 修改菜单]
     */
    public function edit_rule(){
        $menu = new MenuModel();
        if(request()->isPost()){
            $param = input('post.');
            $flag = $menu->editMenu($param);
            if($flag['code'] == 1){
                writelog($this->store['user']['uid'], $this->store['user']['user_name'], '用户【'.$this->store['user']['user_name'].'】添加修改了'.$param['name'].'菜单', 1);
                return $this->renderSuccess($flag['msg'],(string)url('menu/index'),$flag['data']);
            }
            return $this->renderError($flag['msg'],(string)url('menu/index'),$flag['data']);
        }
        $id = input('param.id');
        View::assign('menu',$menu->getOneMenu($id));
        return View('');
    }

    /**
     * [rule_state 修改状态]
     */
    public function rule_state(){
        $id = input('post.id');
        $menu = new MenuModel();
        $res = $menu->update_status($id);
        if($res['code'] == 1){
            return json_encode($this->renderSuccess($res['msg']));
        }
        return json_encode($this->renderError($res['msg']));
    }
    /**
     * [del_rule 删除菜单]
     */
    public function del_rule(){
        $id = input('param.id');
        $menu = new MenuModel();
        $param = $menu->getOneMenu($id);
        $flag = $menu->delMenu($id);
        if($flag['code'] == 1){
            writelog($this->store['user']['uid'], $this->store['user']['user_name'], '用户【'.$this->store['user']['user_name'].'】删除了'.$param['title'].'菜单', 1);
            return $this->renderSuccess($flag['msg'],(string)url('menu/index'));
        }
        return $this->renderError($flag['msg']);
    }
}