<?php


namespace app\admin\validate;


use think\Validate;

class AdminValidate extends Validate
{
    /**
     * 定义验证规则
     * 格式：'字段名'    =>    ['规则1','规则2'...]
     *
     * @var array
     */
    protected $rule = [
        'user_name' => ['require', 'alphaDash'],
        'password' => 'require',
    ];
    /**
     * 定义错误信息
     * 格式：'字段名.规则名'    =>    '错误信息'
     *
     * @var array
     */
    protected $message = [
        'user_name.require' => '请填写管理员账号',
        'user_name.alphaDash' => '管理员账号为应为和字母',
        'password.require' => '请输入密码',
    ];

    protected $scene = [
        'get' => ['user_name', 'password'],
        'update' => ['account', 'roles'],
    ];

}