<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/2/11
 * Time: 14:33
 */

namespace app\admin\validate;


use think\Validate;

class UserValidate extends Validate
{
    protected $rule = [
        'user_name|管理员名称'=> 'require|unique:admin',
        'real_name|真实姓名'=> 'require|unique:admin',
        'mobile|手机号码'=> 'require|unique:admin|length:11',
        'password|密码'=> 'max:32',
    ];
}