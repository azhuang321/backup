<?php


namespace app\admin\common\model;


use think\Model;

class BaseModel extends Model
{

}