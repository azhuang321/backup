<?php


namespace app\admin\common\model;


class Admin extends BaseModel
{
    protected $table = "study_admin";
}