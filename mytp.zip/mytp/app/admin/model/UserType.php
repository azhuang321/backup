<?php


namespace app\admin\model;

use app\admin\validate\RoleValidate;
use think\facade\Db;
use think\model\concern\SoftDelete;
class UserType extends BaseModel
{
    protected $name = "auth_group";
    use SoftDelete;
    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = true;


    /**
     * [getRole 获取所有的角色信息]
     */
    public function getRole()
    {
//        return $this->where('id','<>',1)->where('id','<>',2)->select();
        return $this->where('id','<>',1)->select();
    }

    /**
     * [getRoleInfo 获取角色信息]
     */
    public function getRoleInfo($id){

        $result = Db::name('auth_group')->where('id', $id)->find();
        if(empty($result['rules'])){
            $where = '';
        }else{
            $where = 'id in('.$result['rules'].')';
        }
        $res = Db::name('auth_rule')->field('name')->where($where)->select();
        foreach($res as $key=>$vo){
            if('#' != $vo['name']){
                $result['name'][] = $vo['name'];
            }
        }
        return $result;
    }

    /**
     * [insertRole 插入角色信息]
     */
    public function insertRole($param)
    {
        try{
            $result = Db::name("auth_group")->where("title",$param['title'])->find();
            if($result){
                return ['code' => -1, 'msg' => "角色已经存在"];
            }else{
                UserType::insert($param);
                return ['code' => 1, 'data' => '', 'msg' => '添加角色成功'];
            }
        }catch( PDOException $e){
            return ['code' => -2, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
    /**
     * [editRole 编辑角色信息]
     */
    public function editRole($param)
    {
        try{
            $result = Db::name("auth_group")->where("title",$param['title'])->find();
            if($result){
                return ['code' => -1, 'msg' => "角色已经存在"];
            }else{
                UserType::update($param, ['id' => $param['id']]);
                return ['code' => 1, 'data' => '', 'msg' => '编辑角色成功'];
            }
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * [getRole 获取角色的权限节点]
     */
    public function getRuleById($id)
    {
        $res = $this->field('rules')->where('id', $id)->find();
        return $res['rules'];
    }
    /**
     * [editAccess 分配权限]
     */
    public function editAccess($param)
    {
        try{
            UserType::update($param, ['id' => $param['id']]);
            return ['code' => 1, 'data' => '', 'msg' => '分配权限成功'];

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
}