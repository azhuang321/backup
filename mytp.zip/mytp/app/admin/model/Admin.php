<?php


namespace app\admin\model;

use app\admin\common\model\Admin as AdminModel;
use app\admin\controller\CacheService;
use app\admin\validate\AdminValidate;

use think\exception\ValidateException;

class Admin extends AdminModel{

    protected $table = "study_admin";

    public function login(array $data,string $type){
        //验证规则
        try {
            validate(AdminValidate::class)->scene('get')
                ->check([
                    'user_name' => $data['user_name'],
                    'password' => $data['password']
                ]);
        } catch (ValidateException $e) {
            // 验证失败 输出错误信息
            return ['code' => -1, 'msg' => $e->getError()];
        }
        //验证图形码
//        if(!captcha_check($data['captcha'])){
//            $this->error = '图形码错误';
//            return false;
////            return ['code' => -1, 'msg' => '图形码错误'];
//        }
//        $geetest = [
//            'geetest_challenge' => $data['geetest_challenge'],
//            'geetest_validate' => $data['geetest_validate'],
//            'geetest_seccode' => $data['geetest_seccode']
//        ];

//        if(intval(geetest_chcek_verify($geetest)) == 0){
//            $this->error = '请验证拼图';
//            return false;
//        };

        try{
            $adminInfo = $this->verifyLogin($data['user_name'], $data['password']);
            $exptime = 3600;
            CacheService::createToken($adminInfo['id'], $exptime, $type,"token_admin");
            $param = [
                'loginnum' => $adminInfo['loginnum']+1,
                'last_login_ip' =>request()->ip(),
                'last_login_time' => time(),
            ];
            self::where('id',$adminInfo['id'])->update($param);
            writelog($adminInfo['id'], $adminInfo['user_name'], '用户【' . $adminInfo['user_name'] . '】登录成功', 1);
        }catch (\Exception $e){
            // 这是进行异常捕获
            return ['code' => -1, 'msg' => $e->getMessage()];
        }
        return true;
    }
    /**
     * 管理员登陆
     * @param string $user_name
     * @param string $password
     * @return array|\think\Model
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\Exception
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function verifyLogin(string $user_name, string $password){
        $hash_pwd = study_hash($password);
        // 验证用户名密码是否正确
        if(!$user = self::where([
            'user_name' => $user_name,
            'password' => $hash_pwd
        ])->find()){
            throw new \think\Exception('管理员不存在！', 10006);
        }
        if (!$user) {
            // 使用think自带异常类抛出异常
            throw new \think\Exception('登录失败, 用户名或密码错误!', 10006);
        }
        if (!$user['status']) {
            throw new \think\Exception('您已被禁止登录!', 10006);
        }
        return $user;
    }
    //状态
    public function update_status($id){
        $status = self::where('id','=',$id)->value('status');
        if($status == 1){
            self::where('id','=',$id)->update(['status'=>0]);
            return ['code'=>1,'msg'=>'已禁止'];
        }else{
            self::where('id','=',$id)->update(['status'=>1]);
            return ['code'=>0,'msg'=>'已开启'];
        }
    }
}