<?php


namespace app\admin\model;


class Menu extends BaseModel
{
    protected $name = 'auth_rule';

    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = true;

    /**
     * [getAllMenu 获取全部菜单]
     */
    public function getAllMenu()
    {
        return $this->order('sort asc')->select();
    }

    /**
     * [insertMenu 添加菜单]
     */
    public function insertMenu($param)
    {
        try{
            $param['create_time'] = time();
            $result = self::insert($param);
            if(false === $result){
                return ['code' => -1, 'data' => '', 'msg' => "添加失败"];
            }else{
                return ['code' => 1, 'data' => '', 'msg' => '添加菜单成功'];
            }
        }catch( PDOException $e){
            return ['code' => -2, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
    /**
     * [editMenu 编辑菜单]
     */
    public function editMenu($param)
    {
        try{
            $result =  self::update($param, ['id' => $param['id']]);
            if(false === $result){
                return ['code' => 0, 'data' => '', 'msg' => "添加失败"];
            }else{
                return ['code' => 1, 'data' => '', 'msg' => '编辑菜单成功'];
            }
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * [update_status 修改状态]
     */
    public function update_status($id){
        $status = self::where('id','=',$id)->value('status');
        if($status == 1){
            self::where('id','=',$id)->update(['status'=>0]);
            return ['code'=>1,'msg'=>'已禁止'];
        }else{
            self::where('id','=',$id)->update(['status'=>1]);
            return ['code'=>0,'msg'=>'已开启'];
        }
    }
    /**
     * [getOneMenu 根据菜单id获取一条信息]
     */
    public function getOneMenu($id)
    {
        return $this->where('id', $id)->find();
    }

    /**
     * [delMenu 删除菜单]
     */
    public function delMenu($id)
    {
        try{
            $res = $this->where('id', $id)->delete();
            if($res == 1){
                $this->where('pid',$id)->delete();
            }
            return ['code' => 1, 'data' => '', 'msg' => '删除菜单成功'];
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
}