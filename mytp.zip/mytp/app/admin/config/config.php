<?php

//return [
//    // 默认输出类型
//    'default_return_type'    => 'html',
//
//    'template'               => [
//        // layout布局
//        'layout_on'     =>  true,
//        'layout_name'   =>  'layouts/layout',
//    ],
//];

return [
    'GEETEST_ID'             => '',//极验id  仅供测试使用
    'GEETEST_KEY'            => '',//极验key 仅供测试使用
];
