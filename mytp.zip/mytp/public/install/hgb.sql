/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : 127.0.0.1:3306
 Source Schema         : hgb

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 29/06/2021 19:06:27
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for study_admin
-- ----------------------------
DROP TABLE IF EXISTS `study_admin`;
CREATE TABLE `study_admin`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT '用户名',
  `mobile` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '手机',
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT '密码',
  `portrait` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '头像',
  `loginnum` int(11) NULL DEFAULT 0 COMMENT '登陆次数',
  `last_login_ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) NULL DEFAULT 0 COMMENT '最后登录时间',
  `real_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT '真实姓名',
  `status` int(1) NULL DEFAULT 0 COMMENT '状态',
  `groupid` int(11) NULL DEFAULT 1 COMMENT '用户角色id',
  `token` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `delete_time` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for study_auth_group
-- ----------------------------
DROP TABLE IF EXISTS `study_auth_group`;
CREATE TABLE `study_auth_group`  (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `rules` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `create_time` int(11) NULL DEFAULT NULL,
  `update_time` int(11) NULL DEFAULT NULL,
  `delete_time` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of study_auth_group
-- ----------------------------
INSERT INTO `study_auth_group` VALUES (1, '开发者', 1, '', 1529926348, 1624720717, NULL);
INSERT INTO `study_auth_group` VALUES (2, '全局管理员', 1, '1,2,4,5,8,9,3,11,12,13,14,15,16,17,19,7,20,21,32', 1581320740, 1624949947, NULL);

-- ----------------------------
-- Table structure for study_auth_group_access
-- ----------------------------
DROP TABLE IF EXISTS `study_auth_group_access`;
CREATE TABLE `study_auth_group_access`  (
  `uid` mediumint(8) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL,
  UNIQUE INDEX `uid_group_id`(`uid`, `group_id`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE,
  INDEX `group_id`(`group_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for study_auth_rule
-- ----------------------------
DROP TABLE IF EXISTS `study_auth_rule`;
CREATE TABLE `study_auth_rule`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(80) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `title` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `css` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '样式',
  `condition` char(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0 COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT 0 COMMENT '添加时间',
  `update_time` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of study_auth_rule
-- ----------------------------
INSERT INTO `study_auth_rule` VALUES (1, '#', '系统管理', 1, 1, '', '', 0, 1, 1581347912, 1581421787);
INSERT INTO `study_auth_rule` VALUES (2, 'admin/menu/index', '菜单管理', 1, 1, '', '', 1, 1, 1581347912, 1581405178);
INSERT INTO `study_auth_rule` VALUES (3, 'admin/authority/index', '权限管理', 1, 1, '', '', 1, 0, 0, NULL);
INSERT INTO `study_auth_rule` VALUES (4, 'admin/menu/add_rule', '添加菜单', 1, 1, '', '', 2, 2, 1581405283, 1581405283);
INSERT INTO `study_auth_rule` VALUES (5, 'admin/menu/edit_rule', '编辑菜单', 1, 1, '', '', 2, 2, 1581405331, 1581405331);
INSERT INTO `study_auth_rule` VALUES (7, 'admin/config/index', '配置管理', 1, 1, '', '', 1, 1, 1581411804, 1581421397);
INSERT INTO `study_auth_rule` VALUES (8, 'admin/menu/rule_state', '菜单状态', 1, 1, '', '', 2, 2, 1581418801, 1581418801);
INSERT INTO `study_auth_rule` VALUES (9, 'admin/menu/del_rule', '菜单删除', 1, 1, '', '', 2, 2, 1581418832, 1581418832);
INSERT INTO `study_auth_rule` VALUES (11, 'admin/authority/userAdd', '管理员添加', 1, 1, '', '', 3, 2, 1581418957, 1581418957);
INSERT INTO `study_auth_rule` VALUES (12, 'admin/authority/roleAdd', '角色添加', 1, 1, '', '', 3, 2, 1581419250, 1581419250);
INSERT INTO `study_auth_rule` VALUES (13, 'admin/authority/roleEdit', '角色编辑', 1, 1, '', '', 3, 2, 1581419287, 1581419287);
INSERT INTO `study_auth_rule` VALUES (14, 'admin/authority/roleDel', '角色删除', 1, 1, '', '', 3, 2, 1581419325, 1581419325);
INSERT INTO `study_auth_rule` VALUES (15, 'admin/authority/giveAccess', '权限编辑', 1, 1, '', '', 3, 2, 1581419349, 1581419349);
INSERT INTO `study_auth_rule` VALUES (16, 'admin/authority/user_state', '管理员状态', 1, 1, '', '', 3, 2, 1581419398, 1581419398);
INSERT INTO `study_auth_rule` VALUES (17, 'admin/authority/user_edit', '管理员编辑', 1, 1, '', '', 3, 2, 1581421310, 1581421310);
INSERT INTO `study_auth_rule` VALUES (19, 'admin/authority/userDel', '管理员删除', 1, 1, '', '', 3, 2, 1581421414, 1581421414);
INSERT INTO `study_auth_rule` VALUES (20, '#', '日志管理', 1, 1, '', '', 0, 1, 1581423454, 1581423454);
INSERT INTO `study_auth_rule` VALUES (21, 'admin/log/operate_log', '行为日志', 1, 1, '', '', 20, 2, 1581423576, 1624878937);
INSERT INTO `study_auth_rule` VALUES (32, 'admin/log/del_log', '删除日志', 1, 1, '1', '', 21, 2, 1624949927, 1624949935);

-- ----------------------------
-- Table structure for study_config
-- ----------------------------
DROP TABLE IF EXISTS `study_config`;
CREATE TABLE `study_config`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_name`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for study_log
-- ----------------------------
DROP TABLE IF EXISTS `study_log`;
CREATE TABLE `study_log`  (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NULL DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '描述',
  `ip` char(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) NULL DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) NULL DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 127 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
